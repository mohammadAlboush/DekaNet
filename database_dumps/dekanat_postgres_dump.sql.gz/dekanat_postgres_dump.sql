--
-- PostgreSQL database dump
--

\restrict I7WE8rmEdFCvcjdFnbeXCgUZQYRwsqngGoIouYKEGGkRvWH1QDEelp9TaNPilzH

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.wunsch_freie_tage DROP CONSTRAINT IF EXISTS wunsch_freie_tage_semesterplanung_id_fkey;
ALTER TABLE IF EXISTS ONLY public.template_module DROP CONSTRAINT IF EXISTS template_module_template_id_fkey;
ALTER TABLE IF EXISTS ONLY public.template_module DROP CONSTRAINT IF EXISTS template_module_po_id_fkey;
ALTER TABLE IF EXISTS ONLY public.template_module DROP CONSTRAINT IF EXISTS template_module_modul_id_fkey;
ALTER TABLE IF EXISTS ONLY public.semesterplanung DROP CONSTRAINT IF EXISTS semesterplanung_semester_id_fkey;
ALTER TABLE IF EXISTS ONLY public.semesterplanung DROP CONSTRAINT IF EXISTS semesterplanung_planungsphase_id_fkey;
ALTER TABLE IF EXISTS ONLY public.semesterplanung DROP CONSTRAINT IF EXISTS semesterplanung_freigegeben_von_fkey;
ALTER TABLE IF EXISTS ONLY public.semesterplanung DROP CONSTRAINT IF EXISTS semesterplanung_benutzer_id_fkey;
ALTER TABLE IF EXISTS ONLY public.semester_auftrag DROP CONSTRAINT IF EXISTS semester_auftrag_semester_id_fkey;
ALTER TABLE IF EXISTS ONLY public.semester_auftrag DROP CONSTRAINT IF EXISTS semester_auftrag_genehmigt_von_fkey;
ALTER TABLE IF EXISTS ONLY public.semester_auftrag DROP CONSTRAINT IF EXISTS semester_auftrag_dozent_id_fkey;
ALTER TABLE IF EXISTS ONLY public.semester_auftrag DROP CONSTRAINT IF EXISTS semester_auftrag_beantragt_von_fkey;
ALTER TABLE IF EXISTS ONLY public.semester_auftrag DROP CONSTRAINT IF EXISTS semester_auftrag_auftrag_id_fkey;
ALTER TABLE IF EXISTS ONLY public.planungsphasen DROP CONSTRAINT IF EXISTS planungsphasen_semester_id_fkey;
ALTER TABLE IF EXISTS ONLY public.planungsphasen DROP CONSTRAINT IF EXISTS planungsphasen_geschlossen_von_fkey;
ALTER TABLE IF EXISTS ONLY public.planungs_templates DROP CONSTRAINT IF EXISTS planungs_templates_benutzer_id_fkey;
ALTER TABLE IF EXISTS ONLY public.phase_submissions DROP CONSTRAINT IF EXISTS phase_submissions_professor_id_fkey;
ALTER TABLE IF EXISTS ONLY public.phase_submissions DROP CONSTRAINT IF EXISTS phase_submissions_planungphase_id_fkey;
ALTER TABLE IF EXISTS ONLY public.phase_submissions DROP CONSTRAINT IF EXISTS phase_submissions_planung_id_fkey;
ALTER TABLE IF EXISTS ONLY public.phase_submissions DROP CONSTRAINT IF EXISTS phase_submissions_freigegeben_von_fkey;
ALTER TABLE IF EXISTS ONLY public.phase_submissions DROP CONSTRAINT IF EXISTS phase_submissions_abgelehnt_von_fkey;
ALTER TABLE IF EXISTS ONLY public.modulhandbuch DROP CONSTRAINT IF EXISTS modulhandbuch_studiengang_id_fkey;
ALTER TABLE IF EXISTS ONLY public.modulhandbuch DROP CONSTRAINT IF EXISTS modulhandbuch_po_id_fkey;
ALTER TABLE IF EXISTS ONLY public.modul_voraussetzungen DROP CONSTRAINT IF EXISTS modul_voraussetzungen_po_id_fkey;
ALTER TABLE IF EXISTS ONLY public.modul_voraussetzungen DROP CONSTRAINT IF EXISTS modul_voraussetzungen_modul_id_fkey;
ALTER TABLE IF EXISTS ONLY public.modul_studiengang DROP CONSTRAINT IF EXISTS modul_studiengang_studiengang_id_fkey;
ALTER TABLE IF EXISTS ONLY public.modul_studiengang DROP CONSTRAINT IF EXISTS modul_studiengang_po_id_fkey;
ALTER TABLE IF EXISTS ONLY public.modul_studiengang DROP CONSTRAINT IF EXISTS modul_studiengang_modul_id_fkey;
ALTER TABLE IF EXISTS ONLY public.modul_sprache DROP CONSTRAINT IF EXISTS modul_sprache_sprache_id_fkey;
ALTER TABLE IF EXISTS ONLY public.modul_sprache DROP CONSTRAINT IF EXISTS modul_sprache_po_id_fkey;
ALTER TABLE IF EXISTS ONLY public.modul_sprache DROP CONSTRAINT IF EXISTS modul_sprache_modul_id_fkey;
ALTER TABLE IF EXISTS ONLY public.modul_seiten DROP CONSTRAINT IF EXISTS modul_seiten_po_id_fkey;
ALTER TABLE IF EXISTS ONLY public.modul_seiten DROP CONSTRAINT IF EXISTS modul_seiten_modulhandbuch_id_fkey;
ALTER TABLE IF EXISTS ONLY public.modul_seiten DROP CONSTRAINT IF EXISTS modul_seiten_modul_id_fkey;
ALTER TABLE IF EXISTS ONLY public.modul_pruefung DROP CONSTRAINT IF EXISTS modul_pruefung_po_id_fkey;
ALTER TABLE IF EXISTS ONLY public.modul_pruefung DROP CONSTRAINT IF EXISTS modul_pruefung_modul_id_fkey;
ALTER TABLE IF EXISTS ONLY public.modul DROP CONSTRAINT IF EXISTS modul_po_id_fkey;
ALTER TABLE IF EXISTS ONLY public.modul_literatur DROP CONSTRAINT IF EXISTS modul_literatur_po_id_fkey;
ALTER TABLE IF EXISTS ONLY public.modul_literatur DROP CONSTRAINT IF EXISTS modul_literatur_modul_id_fkey;
ALTER TABLE IF EXISTS ONLY public.modul_lernergebnisse DROP CONSTRAINT IF EXISTS modul_lernergebnisse_po_id_fkey;
ALTER TABLE IF EXISTS ONLY public.modul_lernergebnisse DROP CONSTRAINT IF EXISTS modul_lernergebnisse_modul_id_fkey;
ALTER TABLE IF EXISTS ONLY public.modul_lehrform DROP CONSTRAINT IF EXISTS modul_lehrform_po_id_fkey;
ALTER TABLE IF EXISTS ONLY public.modul_lehrform DROP CONSTRAINT IF EXISTS modul_lehrform_modul_id_fkey;
ALTER TABLE IF EXISTS ONLY public.modul_lehrform DROP CONSTRAINT IF EXISTS modul_lehrform_lehrform_id_fkey;
ALTER TABLE IF EXISTS ONLY public.modul_dozent DROP CONSTRAINT IF EXISTS modul_dozent_zweitpruefer_id_fkey;
ALTER TABLE IF EXISTS ONLY public.modul_dozent DROP CONSTRAINT IF EXISTS modul_dozent_vertreter_id_fkey;
ALTER TABLE IF EXISTS ONLY public.modul_dozent DROP CONSTRAINT IF EXISTS modul_dozent_po_id_fkey;
ALTER TABLE IF EXISTS ONLY public.modul_dozent DROP CONSTRAINT IF EXISTS modul_dozent_modul_id_fkey;
ALTER TABLE IF EXISTS ONLY public.modul_dozent DROP CONSTRAINT IF EXISTS modul_dozent_dozent_id_fkey;
ALTER TABLE IF EXISTS ONLY public.modul_audit_log DROP CONSTRAINT IF EXISTS modul_audit_log_po_id_fkey;
ALTER TABLE IF EXISTS ONLY public.modul_audit_log DROP CONSTRAINT IF EXISTS modul_audit_log_neu_dozent_id_fkey;
ALTER TABLE IF EXISTS ONLY public.modul_audit_log DROP CONSTRAINT IF EXISTS modul_audit_log_modul_id_fkey;
ALTER TABLE IF EXISTS ONLY public.modul_audit_log DROP CONSTRAINT IF EXISTS modul_audit_log_geaendert_von_fkey;
ALTER TABLE IF EXISTS ONLY public.modul_audit_log DROP CONSTRAINT IF EXISTS modul_audit_log_alt_dozent_id_fkey;
ALTER TABLE IF EXISTS ONLY public.modul_arbeitsaufwand DROP CONSTRAINT IF EXISTS modul_arbeitsaufwand_po_id_fkey;
ALTER TABLE IF EXISTS ONLY public.modul_arbeitsaufwand DROP CONSTRAINT IF EXISTS modul_arbeitsaufwand_modul_id_fkey;
ALTER TABLE IF EXISTS ONLY public."modul_abhÃ¤ngigkeit" DROP CONSTRAINT IF EXISTS "modul_abhÃ¤ngigkeit_voraussetzung_modul_id_fkey";
ALTER TABLE IF EXISTS ONLY public."modul_abhÃ¤ngigkeit" DROP CONSTRAINT IF EXISTS "modul_abhÃ¤ngigkeit_po_id_fkey";
ALTER TABLE IF EXISTS ONLY public."modul_abhÃ¤ngigkeit" DROP CONSTRAINT IF EXISTS "modul_abhÃ¤ngigkeit_modul_id_fkey";
ALTER TABLE IF EXISTS ONLY public.geplante_module DROP CONSTRAINT IF EXISTS geplante_module_semesterplanung_id_fkey;
ALTER TABLE IF EXISTS ONLY public.geplante_module DROP CONSTRAINT IF EXISTS geplante_module_po_id_fkey;
ALTER TABLE IF EXISTS ONLY public.geplante_module DROP CONSTRAINT IF EXISTS geplante_module_modul_id_fkey;
ALTER TABLE IF EXISTS ONLY public.deputatsabrechnung DROP CONSTRAINT IF EXISTS deputatsabrechnung_planungsphase_id_fkey;
ALTER TABLE IF EXISTS ONLY public.deputatsabrechnung DROP CONSTRAINT IF EXISTS deputatsabrechnung_genehmigt_von_fkey;
ALTER TABLE IF EXISTS ONLY public.deputatsabrechnung DROP CONSTRAINT IF EXISTS deputatsabrechnung_benutzer_id_fkey;
ALTER TABLE IF EXISTS ONLY public.deputats_vertretung DROP CONSTRAINT IF EXISTS deputats_vertretung_deputatsabrechnung_id_fkey;
ALTER TABLE IF EXISTS ONLY public.deputats_lehrtaetigkeit DROP CONSTRAINT IF EXISTS deputats_lehrtaetigkeit_geplantes_modul_id_fkey;
ALTER TABLE IF EXISTS ONLY public.deputats_lehrtaetigkeit DROP CONSTRAINT IF EXISTS deputats_lehrtaetigkeit_deputatsabrechnung_id_fkey;
ALTER TABLE IF EXISTS ONLY public.deputats_lehrexport DROP CONSTRAINT IF EXISTS deputats_lehrexport_deputatsabrechnung_id_fkey;
ALTER TABLE IF EXISTS ONLY public.deputats_ermaessigung DROP CONSTRAINT IF EXISTS deputats_ermaessigung_semester_auftrag_id_fkey;
ALTER TABLE IF EXISTS ONLY public.deputats_ermaessigung DROP CONSTRAINT IF EXISTS deputats_ermaessigung_deputatsabrechnung_id_fkey;
ALTER TABLE IF EXISTS ONLY public.deputats_einstellungen DROP CONSTRAINT IF EXISTS deputats_einstellungen_erstellt_von_fkey;
ALTER TABLE IF EXISTS ONLY public.deputats_betreuung DROP CONSTRAINT IF EXISTS deputats_betreuung_deputatsabrechnung_id_fkey;
ALTER TABLE IF EXISTS ONLY public.benutzer DROP CONSTRAINT IF EXISTS benutzer_rolle_id_fkey;
ALTER TABLE IF EXISTS ONLY public.benutzer DROP CONSTRAINT IF EXISTS benutzer_dozent_id_fkey;
ALTER TABLE IF EXISTS ONLY public.benachrichtigung DROP CONSTRAINT IF EXISTS benachrichtigung_empfaenger_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_benutzer_id_fkey;
ALTER TABLE IF EXISTS ONLY public.archivierte_planungen DROP CONSTRAINT IF EXISTS archivierte_planungen_semester_id_fkey;
ALTER TABLE IF EXISTS ONLY public.archivierte_planungen DROP CONSTRAINT IF EXISTS archivierte_planungen_professor_id_fkey;
ALTER TABLE IF EXISTS ONLY public.archivierte_planungen DROP CONSTRAINT IF EXISTS archivierte_planungen_planungphase_id_fkey;
ALTER TABLE IF EXISTS ONLY public.archivierte_planungen DROP CONSTRAINT IF EXISTS archivierte_planungen_archiviert_von_fkey;
DROP INDEX IF EXISTS public.ix_wunsch_freie_tage_semesterplanung_id;
DROP INDEX IF EXISTS public.ix_template_module_template_id;
DROP INDEX IF EXISTS public.ix_template_module_modul_id;
DROP INDEX IF EXISTS public.ix_template_modul_template;
DROP INDEX IF EXISTS public.ix_template_benutzer_aktiv;
DROP INDEX IF EXISTS public.ix_semesterplanung_status_semester;
DROP INDEX IF EXISTS public.ix_semesterplanung_status;
DROP INDEX IF EXISTS public.ix_semesterplanung_semester_id;
DROP INDEX IF EXISTS public.ix_semesterplanung_planungsphase_id;
DROP INDEX IF EXISTS public.ix_semesterplanung_benutzer_status;
DROP INDEX IF EXISTS public.ix_semesterplanung_benutzer_id;
DROP INDEX IF EXISTS public.ix_semester_kuerzel;
DROP INDEX IF EXISTS public.ix_semester_ist_planungsphase;
DROP INDEX IF EXISTS public.ix_semester_ist_aktiv;
DROP INDEX IF EXISTS public.ix_semester_auftrag_unique;
DROP INDEX IF EXISTS public.ix_semester_auftrag_status;
DROP INDEX IF EXISTS public.ix_semester_auftrag_semester_id;
DROP INDEX IF EXISTS public.ix_semester_auftrag_semester;
DROP INDEX IF EXISTS public.ix_semester_auftrag_dozent_id;
DROP INDEX IF EXISTS public.ix_semester_auftrag_dozent;
DROP INDEX IF EXISTS public.ix_semester_auftrag_auftrag_id;
DROP INDEX IF EXISTS public.ix_rolle_name;
DROP INDEX IF EXISTS public.ix_planungs_templates_semester_typ;
DROP INDEX IF EXISTS public.ix_planungs_templates_benutzer_id;
DROP INDEX IF EXISTS public.ix_modul_studiengang_studiengang_id;
DROP INDEX IF EXISTS public.ix_modul_studiengang_modul_id;
DROP INDEX IF EXISTS public.ix_modul_po_id;
DROP INDEX IF EXISTS public.ix_modul_lehrform_modul_id;
DROP INDEX IF EXISTS public.ix_modul_kuerzel;
DROP INDEX IF EXISTS public.ix_modul_dozent_zweitpruefer_id;
DROP INDEX IF EXISTS public.ix_modul_dozent_vertreter_id;
DROP INDEX IF EXISTS public.ix_modul_dozent_modul_id;
DROP INDEX IF EXISTS public.ix_modul_dozent_dozent_id;
DROP INDEX IF EXISTS public.ix_modul_audit_modul_datum;
DROP INDEX IF EXISTS public.ix_modul_audit_log_modul_id;
DROP INDEX IF EXISTS public.ix_modul_audit_log_created_at;
DROP INDEX IF EXISTS public.ix_geplantes_modul_planung;
DROP INDEX IF EXISTS public.ix_geplante_module_semesterplanung_id;
DROP INDEX IF EXISTS public.ix_geplante_module_modul_id;
DROP INDEX IF EXISTS public.ix_deputatsabrechnung_status;
DROP INDEX IF EXISTS public.ix_deputatsabrechnung_planungsphase_id;
DROP INDEX IF EXISTS public.ix_deputatsabrechnung_benutzer_id;
DROP INDEX IF EXISTS public.ix_deputats_vertretung_deputatsabrechnung_id;
DROP INDEX IF EXISTS public.ix_deputats_lehrtaetigkeit_deputatsabrechnung_id;
DROP INDEX IF EXISTS public.ix_deputats_lehrexport_deputatsabrechnung_id;
DROP INDEX IF EXISTS public.ix_deputats_ermaessigung_deputatsabrechnung_id;
DROP INDEX IF EXISTS public.ix_deputats_betreuung_deputatsabrechnung_id;
DROP INDEX IF EXISTS public.ix_deputat_status;
DROP INDEX IF EXISTS public.ix_deputat_benutzer_status;
DROP INDEX IF EXISTS public.ix_benutzer_username;
DROP INDEX IF EXISTS public.ix_benutzer_rolle_id;
DROP INDEX IF EXISTS public.ix_benutzer_email;
DROP INDEX IF EXISTS public.ix_benutzer_dozent_id;
DROP INDEX IF EXISTS public.ix_benachrichtigung_gelesen;
DROP INDEX IF EXISTS public.ix_benachrichtigung_empfaenger_id;
DROP INDEX IF EXISTS public.ix_auftrag_name;
DROP INDEX IF EXISTS public.ix_audit_log_timestamp;
DROP INDEX IF EXISTS public.ix_audit_log_benutzer_id;
DROP INDEX IF EXISTS public.ix_audit_log_aktion;
DROP INDEX IF EXISTS public.idx_modul_studiengang;
DROP INDEX IF EXISTS public.idx_modul_po;
DROP INDEX IF EXISTS public.idx_modul_kuerzel;
DROP INDEX IF EXISTS public.idx_modul_dozent;
DROP INDEX IF EXISTS public.idx_dozent_name;
ALTER TABLE IF EXISTS ONLY public.wunsch_freie_tage DROP CONSTRAINT IF EXISTS wunsch_freie_tage_pkey;
ALTER TABLE IF EXISTS ONLY public.template_module DROP CONSTRAINT IF EXISTS uq_template_modul;
ALTER TABLE IF EXISTS ONLY public.planungs_templates DROP CONSTRAINT IF EXISTS uq_template_benutzer_semestertyp;
ALTER TABLE IF EXISTS ONLY public.semesterplanung DROP CONSTRAINT IF EXISTS uq_semester_benutzer_phase;
ALTER TABLE IF EXISTS ONLY public.geplante_module DROP CONSTRAINT IF EXISTS uq_planung_modul;
ALTER TABLE IF EXISTS ONLY public.deputatsabrechnung DROP CONSTRAINT IF EXISTS uq_deputat_phase_benutzer;
ALTER TABLE IF EXISTS ONLY public.phase_submissions DROP CONSTRAINT IF EXISTS unique_professor_phase_approved;
ALTER TABLE IF EXISTS ONLY public.template_module DROP CONSTRAINT IF EXISTS template_module_pkey;
ALTER TABLE IF EXISTS ONLY public.studiengang DROP CONSTRAINT IF EXISTS studiengang_pkey;
ALTER TABLE IF EXISTS ONLY public.studiengang DROP CONSTRAINT IF EXISTS studiengang_kuerzel_key;
ALTER TABLE IF EXISTS ONLY public.sprache DROP CONSTRAINT IF EXISTS sprache_pkey;
ALTER TABLE IF EXISTS ONLY public.sprache DROP CONSTRAINT IF EXISTS sprache_iso_code_key;
ALTER TABLE IF EXISTS ONLY public.sprache DROP CONSTRAINT IF EXISTS sprache_bezeichnung_key;
ALTER TABLE IF EXISTS ONLY public.semesterplanung DROP CONSTRAINT IF EXISTS semesterplanung_pkey;
ALTER TABLE IF EXISTS ONLY public.semester DROP CONSTRAINT IF EXISTS semester_pkey;
ALTER TABLE IF EXISTS ONLY public.semester_auftrag DROP CONSTRAINT IF EXISTS semester_auftrag_pkey;
ALTER TABLE IF EXISTS ONLY public.rolle DROP CONSTRAINT IF EXISTS rolle_pkey;
ALTER TABLE IF EXISTS ONLY public.pruefungsordnung DROP CONSTRAINT IF EXISTS pruefungsordnung_po_jahr_key;
ALTER TABLE IF EXISTS ONLY public.pruefungsordnung DROP CONSTRAINT IF EXISTS pruefungsordnung_pkey;
ALTER TABLE IF EXISTS ONLY public.planungsphasen DROP CONSTRAINT IF EXISTS planungsphasen_pkey;
ALTER TABLE IF EXISTS ONLY public.planungs_templates DROP CONSTRAINT IF EXISTS planungs_templates_pkey;
ALTER TABLE IF EXISTS ONLY public.phase_submissions DROP CONSTRAINT IF EXISTS phase_submissions_pkey;
ALTER TABLE IF EXISTS ONLY public.modulhandbuch DROP CONSTRAINT IF EXISTS modulhandbuch_pkey;
ALTER TABLE IF EXISTS ONLY public.modulhandbuch DROP CONSTRAINT IF EXISTS modulhandbuch_hash_key;
ALTER TABLE IF EXISTS ONLY public.modulhandbuch DROP CONSTRAINT IF EXISTS modulhandbuch_dateiname_key;
ALTER TABLE IF EXISTS ONLY public.modul_voraussetzungen DROP CONSTRAINT IF EXISTS modul_voraussetzungen_pkey;
ALTER TABLE IF EXISTS ONLY public.modul_studiengang DROP CONSTRAINT IF EXISTS modul_studiengang_pkey;
ALTER TABLE IF EXISTS ONLY public.modul_sprache DROP CONSTRAINT IF EXISTS modul_sprache_pkey;
ALTER TABLE IF EXISTS ONLY public.modul_seiten DROP CONSTRAINT IF EXISTS modul_seiten_pkey;
ALTER TABLE IF EXISTS ONLY public.modul_pruefung DROP CONSTRAINT IF EXISTS modul_pruefung_pkey;
ALTER TABLE IF EXISTS ONLY public.modul DROP CONSTRAINT IF EXISTS modul_pkey;
ALTER TABLE IF EXISTS ONLY public.modul_literatur DROP CONSTRAINT IF EXISTS modul_literatur_pkey;
ALTER TABLE IF EXISTS ONLY public.modul_lernergebnisse DROP CONSTRAINT IF EXISTS modul_lernergebnisse_pkey;
ALTER TABLE IF EXISTS ONLY public.modul_lehrform DROP CONSTRAINT IF EXISTS modul_lehrform_pkey;
ALTER TABLE IF EXISTS ONLY public.modul_dozent DROP CONSTRAINT IF EXISTS modul_dozent_pkey;
ALTER TABLE IF EXISTS ONLY public.modul_audit_log DROP CONSTRAINT IF EXISTS modul_audit_log_pkey;
ALTER TABLE IF EXISTS ONLY public.modul_arbeitsaufwand DROP CONSTRAINT IF EXISTS modul_arbeitsaufwand_pkey;
ALTER TABLE IF EXISTS ONLY public."modul_abhÃ¤ngigkeit" DROP CONSTRAINT IF EXISTS "modul_abhÃ¤ngigkeit_pkey";
ALTER TABLE IF EXISTS ONLY public.lehrform DROP CONSTRAINT IF EXISTS lehrform_pkey;
ALTER TABLE IF EXISTS ONLY public.lehrform DROP CONSTRAINT IF EXISTS lehrform_kuerzel_key;
ALTER TABLE IF EXISTS ONLY public.lehrform DROP CONSTRAINT IF EXISTS lehrform_bezeichnung_key;
ALTER TABLE IF EXISTS ONLY public.geplante_module DROP CONSTRAINT IF EXISTS geplante_module_pkey;
ALTER TABLE IF EXISTS ONLY public.dozent DROP CONSTRAINT IF EXISTS dozent_pkey;
ALTER TABLE IF EXISTS ONLY public.deputatsabrechnung DROP CONSTRAINT IF EXISTS deputatsabrechnung_pkey;
ALTER TABLE IF EXISTS ONLY public.deputats_vertretung DROP CONSTRAINT IF EXISTS deputats_vertretung_pkey;
ALTER TABLE IF EXISTS ONLY public.deputats_lehrtaetigkeit DROP CONSTRAINT IF EXISTS deputats_lehrtaetigkeit_pkey;
ALTER TABLE IF EXISTS ONLY public.deputats_lehrexport DROP CONSTRAINT IF EXISTS deputats_lehrexport_pkey;
ALTER TABLE IF EXISTS ONLY public.deputats_ermaessigung DROP CONSTRAINT IF EXISTS deputats_ermaessigung_pkey;
ALTER TABLE IF EXISTS ONLY public.deputats_einstellungen DROP CONSTRAINT IF EXISTS deputats_einstellungen_pkey;
ALTER TABLE IF EXISTS ONLY public.deputats_betreuung DROP CONSTRAINT IF EXISTS deputats_betreuung_pkey;
ALTER TABLE IF EXISTS ONLY public.benutzer DROP CONSTRAINT IF EXISTS benutzer_pkey;
ALTER TABLE IF EXISTS ONLY public.benachrichtigung DROP CONSTRAINT IF EXISTS benachrichtigung_pkey;
ALTER TABLE IF EXISTS ONLY public.auftrag DROP CONSTRAINT IF EXISTS auftrag_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_pkey;
ALTER TABLE IF EXISTS ONLY public.archivierte_planungen DROP CONSTRAINT IF EXISTS archivierte_planungen_pkey;
ALTER TABLE IF EXISTS public.wunsch_freie_tage ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.template_module ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.studiengang ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.sprache ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.semesterplanung ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.semester_auftrag ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.semester ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.rolle ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.pruefungsordnung ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.planungsphasen ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.planungs_templates ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.phase_submissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.modulhandbuch ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.modul_studiengang ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.modul_literatur ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.modul_lehrform ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.modul_dozent ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.modul_audit_log ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public."modul_abhÃ¤ngigkeit" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.modul ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.lehrform ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.geplante_module ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.dozent ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.deputatsabrechnung ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.deputats_vertretung ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.deputats_lehrtaetigkeit ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.deputats_lehrexport ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.deputats_ermaessigung ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.deputats_einstellungen ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.deputats_betreuung ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.benutzer ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.benachrichtigung ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.auftrag ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.audit_log ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.archivierte_planungen ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.wunsch_freie_tage_id_seq;
DROP TABLE IF EXISTS public.wunsch_freie_tage;
DROP SEQUENCE IF EXISTS public.template_module_id_seq;
DROP TABLE IF EXISTS public.template_module;
DROP SEQUENCE IF EXISTS public.studiengang_id_seq;
DROP TABLE IF EXISTS public.studiengang;
DROP SEQUENCE IF EXISTS public.sprache_id_seq;
DROP TABLE IF EXISTS public.sprache;
DROP SEQUENCE IF EXISTS public.semesterplanung_id_seq;
DROP TABLE IF EXISTS public.semesterplanung;
DROP SEQUENCE IF EXISTS public.semester_id_seq;
DROP SEQUENCE IF EXISTS public.semester_auftrag_id_seq;
DROP TABLE IF EXISTS public.semester_auftrag;
DROP TABLE IF EXISTS public.semester;
DROP SEQUENCE IF EXISTS public.rolle_id_seq;
DROP TABLE IF EXISTS public.rolle;
DROP SEQUENCE IF EXISTS public.pruefungsordnung_id_seq;
DROP TABLE IF EXISTS public.pruefungsordnung;
DROP SEQUENCE IF EXISTS public.planungsphasen_id_seq;
DROP TABLE IF EXISTS public.planungsphasen;
DROP SEQUENCE IF EXISTS public.planungs_templates_id_seq;
DROP TABLE IF EXISTS public.planungs_templates;
DROP SEQUENCE IF EXISTS public.phase_submissions_id_seq;
DROP TABLE IF EXISTS public.phase_submissions;
DROP SEQUENCE IF EXISTS public.modulhandbuch_id_seq;
DROP TABLE IF EXISTS public.modulhandbuch;
DROP TABLE IF EXISTS public.modul_voraussetzungen;
DROP SEQUENCE IF EXISTS public.modul_studiengang_id_seq;
DROP TABLE IF EXISTS public.modul_studiengang;
DROP TABLE IF EXISTS public.modul_sprache;
DROP TABLE IF EXISTS public.modul_seiten;
DROP TABLE IF EXISTS public.modul_pruefung;
DROP SEQUENCE IF EXISTS public.modul_literatur_id_seq;
DROP TABLE IF EXISTS public.modul_literatur;
DROP TABLE IF EXISTS public.modul_lernergebnisse;
DROP SEQUENCE IF EXISTS public.modul_lehrform_id_seq;
DROP TABLE IF EXISTS public.modul_lehrform;
DROP SEQUENCE IF EXISTS public.modul_id_seq;
DROP SEQUENCE IF EXISTS public.modul_dozent_id_seq;
DROP TABLE IF EXISTS public.modul_dozent;
DROP SEQUENCE IF EXISTS public.modul_audit_log_id_seq;
DROP TABLE IF EXISTS public.modul_audit_log;
DROP TABLE IF EXISTS public.modul_arbeitsaufwand;
DROP SEQUENCE IF EXISTS public."modul_abhÃ¤ngigkeit_id_seq";
DROP TABLE IF EXISTS public."modul_abhÃ¤ngigkeit";
DROP TABLE IF EXISTS public.modul;
DROP SEQUENCE IF EXISTS public.lehrform_id_seq;
DROP TABLE IF EXISTS public.lehrform;
DROP SEQUENCE IF EXISTS public.geplante_module_id_seq;
DROP TABLE IF EXISTS public.geplante_module;
DROP SEQUENCE IF EXISTS public.dozent_id_seq;
DROP TABLE IF EXISTS public.dozent;
DROP SEQUENCE IF EXISTS public.deputatsabrechnung_id_seq;
DROP TABLE IF EXISTS public.deputatsabrechnung;
DROP SEQUENCE IF EXISTS public.deputats_vertretung_id_seq;
DROP TABLE IF EXISTS public.deputats_vertretung;
DROP SEQUENCE IF EXISTS public.deputats_lehrtaetigkeit_id_seq;
DROP TABLE IF EXISTS public.deputats_lehrtaetigkeit;
DROP SEQUENCE IF EXISTS public.deputats_lehrexport_id_seq;
DROP TABLE IF EXISTS public.deputats_lehrexport;
DROP SEQUENCE IF EXISTS public.deputats_ermaessigung_id_seq;
DROP TABLE IF EXISTS public.deputats_ermaessigung;
DROP SEQUENCE IF EXISTS public.deputats_einstellungen_id_seq;
DROP TABLE IF EXISTS public.deputats_einstellungen;
DROP SEQUENCE IF EXISTS public.deputats_betreuung_id_seq;
DROP TABLE IF EXISTS public.deputats_betreuung;
DROP SEQUENCE IF EXISTS public.benutzer_id_seq;
DROP TABLE IF EXISTS public.benutzer;
DROP SEQUENCE IF EXISTS public.benachrichtigung_id_seq;
DROP TABLE IF EXISTS public.benachrichtigung;
DROP SEQUENCE IF EXISTS public.auftrag_id_seq;
DROP TABLE IF EXISTS public.auftrag;
DROP SEQUENCE IF EXISTS public.audit_log_id_seq;
DROP TABLE IF EXISTS public.audit_log;
DROP SEQUENCE IF EXISTS public.archivierte_planungen_id_seq;
DROP TABLE IF EXISTS public.archivierte_planungen;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: archivierte_planungen; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.archivierte_planungen (
    original_planung_id integer NOT NULL,
    planungphase_id integer NOT NULL,
    professor_id integer NOT NULL,
    professor_name character varying(255) NOT NULL,
    semester_id integer NOT NULL,
    semester_name character varying(255) NOT NULL,
    phase_name character varying(255) NOT NULL,
    status_bei_archivierung character varying(50) NOT NULL,
    archiviert_am timestamp without time zone NOT NULL,
    archiviert_grund character varying(50) NOT NULL,
    archiviert_von integer,
    planung_daten jsonb NOT NULL,
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: archivierte_planungen_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.archivierte_planungen_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: archivierte_planungen_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.archivierte_planungen_id_seq OWNED BY public.archivierte_planungen.id;


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id integer NOT NULL,
    benutzer_id integer,
    aktion character varying(100) NOT NULL,
    tabelle character varying(50),
    datensatz_id integer,
    alte_werte text,
    neue_werte text,
    ip_adresse character varying(50),
    "timestamp" timestamp without time zone NOT NULL
);


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: auftrag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auftrag (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    beschreibung text,
    standard_sws double precision NOT NULL,
    ist_aktiv boolean NOT NULL,
    sortierung integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: auftrag_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.auftrag_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auftrag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.auftrag_id_seq OWNED BY public.auftrag.id;


--
-- Name: benachrichtigung; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.benachrichtigung (
    id integer NOT NULL,
    empfaenger_id integer NOT NULL,
    typ character varying(50) NOT NULL,
    titel character varying(255) NOT NULL,
    nachricht text,
    gelesen boolean NOT NULL,
    erstellt_am timestamp without time zone NOT NULL,
    gelesen_am timestamp without time zone
);


--
-- Name: benachrichtigung_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.benachrichtigung_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: benachrichtigung_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.benachrichtigung_id_seq OWNED BY public.benachrichtigung.id;


--
-- Name: benutzer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.benutzer (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    username character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    rolle_id integer NOT NULL,
    dozent_id integer,
    vorname character varying(100),
    nachname character varying(100),
    aktiv boolean NOT NULL,
    letzter_login timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: benutzer_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.benutzer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: benutzer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.benutzer_id_seq OWNED BY public.benutzer.id;


--
-- Name: deputats_betreuung; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deputats_betreuung (
    id integer NOT NULL,
    deputatsabrechnung_id integer NOT NULL,
    student_name character varying(100) NOT NULL,
    student_vorname character varying(100) NOT NULL,
    titel_arbeit character varying(500),
    betreuungsart character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    beginn_datum date,
    ende_datum date,
    sws double precision NOT NULL,
    created_at timestamp without time zone NOT NULL
);


--
-- Name: deputats_betreuung_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.deputats_betreuung_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: deputats_betreuung_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.deputats_betreuung_id_seq OWNED BY public.deputats_betreuung.id;


--
-- Name: deputats_einstellungen; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deputats_einstellungen (
    id integer NOT NULL,
    sws_bachelor_arbeit double precision NOT NULL,
    sws_master_arbeit double precision NOT NULL,
    sws_doktorarbeit double precision NOT NULL,
    sws_seminar_ba double precision NOT NULL,
    sws_seminar_ma double precision NOT NULL,
    sws_projekt_ba double precision NOT NULL,
    sws_projekt_ma double precision NOT NULL,
    max_sws_praxisseminar double precision NOT NULL,
    max_sws_projektveranstaltung double precision NOT NULL,
    max_sws_seminar_master double precision NOT NULL,
    max_sws_betreuung double precision NOT NULL,
    warn_ermaessigung_ueber double precision NOT NULL,
    default_netto_lehrverpflichtung double precision NOT NULL,
    ist_aktiv boolean NOT NULL,
    beschreibung character varying(500),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    erstellt_von integer
);


--
-- Name: deputats_einstellungen_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.deputats_einstellungen_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: deputats_einstellungen_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.deputats_einstellungen_id_seq OWNED BY public.deputats_einstellungen.id;


--
-- Name: deputats_ermaessigung; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deputats_ermaessigung (
    id integer NOT NULL,
    deputatsabrechnung_id integer NOT NULL,
    bezeichnung character varying(200) NOT NULL,
    sws double precision NOT NULL,
    quelle character varying(20) NOT NULL,
    semester_auftrag_id integer,
    created_at timestamp without time zone NOT NULL
);


--
-- Name: deputats_ermaessigung_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.deputats_ermaessigung_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: deputats_ermaessigung_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.deputats_ermaessigung_id_seq OWNED BY public.deputats_ermaessigung.id;


--
-- Name: deputats_lehrexport; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deputats_lehrexport (
    id integer NOT NULL,
    deputatsabrechnung_id integer NOT NULL,
    fachbereich character varying(100) NOT NULL,
    fach character varying(200) NOT NULL,
    sws double precision NOT NULL,
    created_at timestamp without time zone NOT NULL
);


--
-- Name: deputats_lehrexport_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.deputats_lehrexport_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: deputats_lehrexport_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.deputats_lehrexport_id_seq OWNED BY public.deputats_lehrexport.id;


--
-- Name: deputats_lehrtaetigkeit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deputats_lehrtaetigkeit (
    id integer NOT NULL,
    deputatsabrechnung_id integer NOT NULL,
    bezeichnung character varying(200) NOT NULL,
    kategorie character varying(50) NOT NULL,
    sws double precision NOT NULL,
    wochentag character varying(20),
    wochentage json,
    ist_block boolean NOT NULL,
    quelle character varying(20) NOT NULL,
    geplantes_modul_id integer,
    created_at timestamp without time zone NOT NULL
);


--
-- Name: deputats_lehrtaetigkeit_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.deputats_lehrtaetigkeit_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: deputats_lehrtaetigkeit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.deputats_lehrtaetigkeit_id_seq OWNED BY public.deputats_lehrtaetigkeit.id;


--
-- Name: deputats_vertretung; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deputats_vertretung (
    id integer NOT NULL,
    deputatsabrechnung_id integer NOT NULL,
    art character varying(50) NOT NULL,
    vertretene_person character varying(200) NOT NULL,
    fach_professor character varying(200) NOT NULL,
    sws double precision NOT NULL,
    created_at timestamp without time zone NOT NULL
);


--
-- Name: deputats_vertretung_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.deputats_vertretung_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: deputats_vertretung_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.deputats_vertretung_id_seq OWNED BY public.deputats_vertretung.id;


--
-- Name: deputatsabrechnung; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deputatsabrechnung (
    id integer NOT NULL,
    planungsphase_id integer NOT NULL,
    benutzer_id integer NOT NULL,
    netto_lehrverpflichtung double precision NOT NULL,
    status character varying(50) NOT NULL,
    bemerkungen text,
    eingereicht_am timestamp without time zone,
    genehmigt_von integer,
    genehmigt_am timestamp without time zone,
    abgelehnt_am timestamp without time zone,
    ablehnungsgrund text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: deputatsabrechnung_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.deputatsabrechnung_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: deputatsabrechnung_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.deputatsabrechnung_id_seq OWNED BY public.deputatsabrechnung.id;


--
-- Name: dozent; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dozent (
    id integer NOT NULL,
    titel character varying(50),
    vorname character varying(100),
    nachname character varying(100) NOT NULL,
    name_komplett character varying(200) NOT NULL,
    email character varying(100),
    fachbereich character varying(100),
    aktiv boolean NOT NULL,
    created_at timestamp without time zone NOT NULL
);


--
-- Name: dozent_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.dozent_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dozent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.dozent_id_seq OWNED BY public.dozent.id;


--
-- Name: geplante_module; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.geplante_module (
    id integer NOT NULL,
    semesterplanung_id integer NOT NULL,
    modul_id integer NOT NULL,
    po_id integer NOT NULL,
    anzahl_vorlesungen integer NOT NULL,
    anzahl_uebungen integer NOT NULL,
    anzahl_praktika integer NOT NULL,
    anzahl_seminare integer NOT NULL,
    sws_vorlesung double precision NOT NULL,
    sws_uebung double precision NOT NULL,
    sws_praktikum double precision NOT NULL,
    sws_seminar double precision NOT NULL,
    sws_gesamt double precision NOT NULL,
    mitarbeiter_ids text,
    anmerkungen text,
    raumbedarf text,
    raum_vorlesung character varying(100),
    raum_uebung character varying(100),
    raum_praktikum character varying(100),
    raum_seminar character varying(100),
    kapazitaet_vorlesung integer,
    kapazitaet_uebung integer,
    kapazitaet_praktikum integer,
    kapazitaet_seminar integer,
    created_at timestamp without time zone NOT NULL
);


--
-- Name: geplante_module_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.geplante_module_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: geplante_module_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.geplante_module_id_seq OWNED BY public.geplante_module.id;


--
-- Name: lehrform; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lehrform (
    id integer NOT NULL,
    bezeichnung character varying(50) NOT NULL,
    kuerzel character varying(10)
);


--
-- Name: lehrform_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.lehrform_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: lehrform_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.lehrform_id_seq OWNED BY public.lehrform.id;


--
-- Name: modul; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.modul (
    id integer NOT NULL,
    kuerzel character varying(20) NOT NULL,
    po_id integer NOT NULL,
    bezeichnung_de character varying(200) NOT NULL,
    bezeichnung_en character varying(200),
    untertitel character varying(200),
    leistungspunkte integer,
    turnus character varying(50),
    "gruppengröße" character varying(50),
    teilnehmerzahl character varying(50),
    anmeldemodalitaeten text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: modul_abhÃ¤ngigkeit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."modul_abhÃ¤ngigkeit" (
    id integer NOT NULL,
    modul_id integer NOT NULL,
    voraussetzung_modul_id integer NOT NULL,
    po_id integer NOT NULL,
    typ character varying(20)
);


--
-- Name: modul_abhÃ¤ngigkeit_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."modul_abhÃ¤ngigkeit_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: modul_abhÃ¤ngigkeit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."modul_abhÃ¤ngigkeit_id_seq" OWNED BY public."modul_abhÃ¤ngigkeit".id;


--
-- Name: modul_arbeitsaufwand; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.modul_arbeitsaufwand (
    modul_id integer NOT NULL,
    po_id integer NOT NULL,
    kontaktzeit_stunden integer,
    selbststudium_stunden integer,
    pruefungsvorbereitung_stunden integer,
    gesamt_stunden integer
);


--
-- Name: modul_audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.modul_audit_log (
    id integer NOT NULL,
    modul_id integer NOT NULL,
    po_id integer NOT NULL,
    geaendert_von integer,
    aktion character varying(50) NOT NULL,
    alt_dozent_id integer,
    neu_dozent_id integer,
    alte_rolle character varying(50),
    neue_rolle character varying(50),
    bemerkung text,
    created_at timestamp without time zone NOT NULL
);


--
-- Name: modul_audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.modul_audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: modul_audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.modul_audit_log_id_seq OWNED BY public.modul_audit_log.id;


--
-- Name: modul_dozent; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.modul_dozent (
    id integer NOT NULL,
    modul_id integer NOT NULL,
    po_id integer NOT NULL,
    dozent_id integer NOT NULL,
    rolle character varying(50) NOT NULL,
    vertreter_id integer,
    zweitpruefer_id integer
);


--
-- Name: modul_dozent_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.modul_dozent_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: modul_dozent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.modul_dozent_id_seq OWNED BY public.modul_dozent.id;


--
-- Name: modul_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.modul_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: modul_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.modul_id_seq OWNED BY public.modul.id;


--
-- Name: modul_lehrform; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.modul_lehrform (
    id integer NOT NULL,
    modul_id integer NOT NULL,
    po_id integer NOT NULL,
    lehrform_id integer NOT NULL,
    sws double precision NOT NULL
);


--
-- Name: modul_lehrform_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.modul_lehrform_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: modul_lehrform_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.modul_lehrform_id_seq OWNED BY public.modul_lehrform.id;


--
-- Name: modul_lernergebnisse; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.modul_lernergebnisse (
    modul_id integer NOT NULL,
    po_id integer NOT NULL,
    lernziele text,
    kompetenzen text,
    inhalt text
);


--
-- Name: modul_literatur; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.modul_literatur (
    id integer NOT NULL,
    modul_id integer NOT NULL,
    po_id integer NOT NULL,
    titel text NOT NULL,
    autoren character varying(500),
    verlag character varying(200),
    jahr integer,
    isbn character varying(20),
    typ character varying(50),
    pflichtliteratur boolean,
    sortierung integer
);


--
-- Name: modul_literatur_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.modul_literatur_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: modul_literatur_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.modul_literatur_id_seq OWNED BY public.modul_literatur.id;


--
-- Name: modul_pruefung; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.modul_pruefung (
    modul_id integer NOT NULL,
    po_id integer NOT NULL,
    pruefungsform character varying(100),
    pruefungsdauer_minuten integer,
    pruefungsleistungen text,
    benotung character varying(50)
);


--
-- Name: modul_seiten; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.modul_seiten (
    modul_id integer NOT NULL,
    po_id integer NOT NULL,
    modulhandbuch_id integer NOT NULL,
    seite_von integer NOT NULL,
    seite_bis integer
);


--
-- Name: modul_sprache; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.modul_sprache (
    modul_id integer NOT NULL,
    po_id integer NOT NULL,
    sprache_id integer NOT NULL
);


--
-- Name: modul_studiengang; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.modul_studiengang (
    id integer NOT NULL,
    modul_id integer NOT NULL,
    po_id integer NOT NULL,
    studiengang_id integer NOT NULL,
    semester integer,
    pflicht boolean,
    wahlpflicht boolean
);


--
-- Name: modul_studiengang_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.modul_studiengang_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: modul_studiengang_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.modul_studiengang_id_seq OWNED BY public.modul_studiengang.id;


--
-- Name: modul_voraussetzungen; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.modul_voraussetzungen (
    modul_id integer NOT NULL,
    po_id integer NOT NULL,
    formal text,
    empfohlen text,
    inhaltlich text
);


--
-- Name: modulhandbuch; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.modulhandbuch (
    id integer NOT NULL,
    dateiname character varying(255) NOT NULL,
    studiengang_id integer,
    po_id integer NOT NULL,
    version character varying(20),
    anzahl_seiten integer,
    anzahl_module integer,
    import_datum timestamp without time zone NOT NULL,
    hash character varying(64)
);


--
-- Name: modulhandbuch_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.modulhandbuch_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: modulhandbuch_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.modulhandbuch_id_seq OWNED BY public.modulhandbuch.id;


--
-- Name: phase_submissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phase_submissions (
    planungphase_id integer NOT NULL,
    professor_id integer NOT NULL,
    planung_id integer NOT NULL,
    eingereicht_am timestamp without time zone NOT NULL,
    status character varying(50) NOT NULL,
    freigegeben_am timestamp without time zone,
    freigegeben_von integer,
    abgelehnt_am timestamp without time zone,
    abgelehnt_von integer,
    abgelehnt_grund text,
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: phase_submissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phase_submissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phase_submissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.phase_submissions_id_seq OWNED BY public.phase_submissions.id;


--
-- Name: planungs_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.planungs_templates (
    id integer NOT NULL,
    benutzer_id integer NOT NULL,
    semester_typ character varying(20) NOT NULL,
    name character varying(100),
    beschreibung text,
    ist_aktiv boolean NOT NULL,
    wunsch_freie_tage text,
    anmerkungen text,
    raumbedarf text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: planungs_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.planungs_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: planungs_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.planungs_templates_id_seq OWNED BY public.planungs_templates.id;


--
-- Name: planungsphasen; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.planungsphasen (
    semester_id integer NOT NULL,
    name character varying(255) NOT NULL,
    startdatum timestamp without time zone NOT NULL,
    enddatum timestamp without time zone,
    ist_aktiv boolean NOT NULL,
    geschlossen_am timestamp without time zone,
    geschlossen_von integer,
    geschlossen_grund text,
    anzahl_einreichungen integer NOT NULL,
    anzahl_genehmigt integer NOT NULL,
    anzahl_abgelehnt integer NOT NULL,
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT chk_dates CHECK (((enddatum IS NULL) OR (enddatum > startdatum)))
);


--
-- Name: planungsphasen_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.planungsphasen_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: planungsphasen_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.planungsphasen_id_seq OWNED BY public.planungsphasen.id;


--
-- Name: pruefungsordnung; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pruefungsordnung (
    id integer NOT NULL,
    po_jahr character varying(10) NOT NULL,
    gueltig_von date NOT NULL,
    gueltig_bis date,
    beschreibung text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: pruefungsordnung_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pruefungsordnung_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pruefungsordnung_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pruefungsordnung_id_seq OWNED BY public.pruefungsordnung.id;


--
-- Name: rolle; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rolle (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    beschreibung text,
    created_at timestamp without time zone
);


--
-- Name: rolle_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rolle_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rolle_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rolle_id_seq OWNED BY public.rolle.id;


--
-- Name: semester; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.semester (
    id integer NOT NULL,
    bezeichnung character varying(50) NOT NULL,
    kuerzel character varying(10) NOT NULL,
    start_datum date NOT NULL,
    ende_datum date NOT NULL,
    vorlesungsbeginn date,
    vorlesungsende date,
    ist_aktiv boolean NOT NULL,
    ist_planungsphase boolean NOT NULL,
    created_at timestamp without time zone NOT NULL
);


--
-- Name: semester_auftrag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.semester_auftrag (
    id integer NOT NULL,
    semester_id integer NOT NULL,
    auftrag_id integer NOT NULL,
    dozent_id integer NOT NULL,
    sws double precision NOT NULL,
    status character varying(20) NOT NULL,
    beantragt_von integer,
    genehmigt_von integer,
    genehmigt_am timestamp without time zone,
    anmerkung text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: semester_auftrag_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.semester_auftrag_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: semester_auftrag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.semester_auftrag_id_seq OWNED BY public.semester_auftrag.id;


--
-- Name: semester_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.semester_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: semester_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.semester_id_seq OWNED BY public.semester.id;


--
-- Name: semesterplanung; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.semesterplanung (
    id integer NOT NULL,
    semester_id integer NOT NULL,
    benutzer_id integer NOT NULL,
    planungsphase_id integer,
    status character varying(50) NOT NULL,
    anmerkungen text,
    raumbedarf text,
    room_requirements text,
    special_requests text,
    gesamt_sws double precision,
    eingereicht_am timestamp without time zone,
    freigegeben_von integer,
    freigegeben_am timestamp without time zone,
    abgelehnt_am timestamp without time zone,
    ablehnungsgrund text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: semesterplanung_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.semesterplanung_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: semesterplanung_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.semesterplanung_id_seq OWNED BY public.semesterplanung.id;


--
-- Name: sprache; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sprache (
    id integer NOT NULL,
    bezeichnung character varying(50) NOT NULL,
    iso_code character varying(5)
);


--
-- Name: sprache_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sprache_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sprache_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sprache_id_seq OWNED BY public.sprache.id;


--
-- Name: studiengang; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.studiengang (
    id integer NOT NULL,
    kuerzel character varying(10) NOT NULL,
    bezeichnung character varying(100) NOT NULL,
    abschluss character varying(20),
    fachbereich character varying(100),
    regelstudienzeit integer,
    ects_gesamt integer,
    aktiv boolean NOT NULL,
    created_at timestamp without time zone NOT NULL
);


--
-- Name: studiengang_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.studiengang_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: studiengang_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.studiengang_id_seq OWNED BY public.studiengang.id;


--
-- Name: template_module; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.template_module (
    id integer NOT NULL,
    template_id integer NOT NULL,
    modul_id integer NOT NULL,
    po_id integer NOT NULL,
    anzahl_vorlesungen integer NOT NULL,
    anzahl_uebungen integer NOT NULL,
    anzahl_praktika integer NOT NULL,
    anzahl_seminare integer NOT NULL,
    mitarbeiter_ids text,
    anmerkungen text,
    raumbedarf text,
    raum_vorlesung character varying(100),
    raum_uebung character varying(100),
    raum_praktikum character varying(100),
    raum_seminar character varying(100),
    kapazitaet_vorlesung integer,
    kapazitaet_uebung integer,
    kapazitaet_praktikum integer,
    kapazitaet_seminar integer,
    created_at timestamp without time zone NOT NULL
);


--
-- Name: template_module_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.template_module_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: template_module_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.template_module_id_seq OWNED BY public.template_module.id;


--
-- Name: wunsch_freie_tage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wunsch_freie_tage (
    id integer NOT NULL,
    semesterplanung_id integer NOT NULL,
    wochentag character varying(20) NOT NULL,
    zeitraum character varying(20) NOT NULL,
    prioritaet character varying(20) NOT NULL,
    bemerkung text,
    grund text
);


--
-- Name: wunsch_freie_tage_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.wunsch_freie_tage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: wunsch_freie_tage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.wunsch_freie_tage_id_seq OWNED BY public.wunsch_freie_tage.id;


--
-- Name: archivierte_planungen id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.archivierte_planungen ALTER COLUMN id SET DEFAULT nextval('public.archivierte_planungen_id_seq'::regclass);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: auftrag id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auftrag ALTER COLUMN id SET DEFAULT nextval('public.auftrag_id_seq'::regclass);


--
-- Name: benachrichtigung id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.benachrichtigung ALTER COLUMN id SET DEFAULT nextval('public.benachrichtigung_id_seq'::regclass);


--
-- Name: benutzer id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.benutzer ALTER COLUMN id SET DEFAULT nextval('public.benutzer_id_seq'::regclass);


--
-- Name: deputats_betreuung id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deputats_betreuung ALTER COLUMN id SET DEFAULT nextval('public.deputats_betreuung_id_seq'::regclass);


--
-- Name: deputats_einstellungen id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deputats_einstellungen ALTER COLUMN id SET DEFAULT nextval('public.deputats_einstellungen_id_seq'::regclass);


--
-- Name: deputats_ermaessigung id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deputats_ermaessigung ALTER COLUMN id SET DEFAULT nextval('public.deputats_ermaessigung_id_seq'::regclass);


--
-- Name: deputats_lehrexport id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deputats_lehrexport ALTER COLUMN id SET DEFAULT nextval('public.deputats_lehrexport_id_seq'::regclass);


--
-- Name: deputats_lehrtaetigkeit id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deputats_lehrtaetigkeit ALTER COLUMN id SET DEFAULT nextval('public.deputats_lehrtaetigkeit_id_seq'::regclass);


--
-- Name: deputats_vertretung id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deputats_vertretung ALTER COLUMN id SET DEFAULT nextval('public.deputats_vertretung_id_seq'::regclass);


--
-- Name: deputatsabrechnung id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deputatsabrechnung ALTER COLUMN id SET DEFAULT nextval('public.deputatsabrechnung_id_seq'::regclass);


--
-- Name: dozent id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dozent ALTER COLUMN id SET DEFAULT nextval('public.dozent_id_seq'::regclass);


--
-- Name: geplante_module id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.geplante_module ALTER COLUMN id SET DEFAULT nextval('public.geplante_module_id_seq'::regclass);


--
-- Name: lehrform id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lehrform ALTER COLUMN id SET DEFAULT nextval('public.lehrform_id_seq'::regclass);


--
-- Name: modul id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul ALTER COLUMN id SET DEFAULT nextval('public.modul_id_seq'::regclass);


--
-- Name: modul_abhÃ¤ngigkeit id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."modul_abhÃ¤ngigkeit" ALTER COLUMN id SET DEFAULT nextval('public."modul_abhÃ¤ngigkeit_id_seq"'::regclass);


--
-- Name: modul_audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_audit_log ALTER COLUMN id SET DEFAULT nextval('public.modul_audit_log_id_seq'::regclass);


--
-- Name: modul_dozent id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_dozent ALTER COLUMN id SET DEFAULT nextval('public.modul_dozent_id_seq'::regclass);


--
-- Name: modul_lehrform id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_lehrform ALTER COLUMN id SET DEFAULT nextval('public.modul_lehrform_id_seq'::regclass);


--
-- Name: modul_literatur id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_literatur ALTER COLUMN id SET DEFAULT nextval('public.modul_literatur_id_seq'::regclass);


--
-- Name: modul_studiengang id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_studiengang ALTER COLUMN id SET DEFAULT nextval('public.modul_studiengang_id_seq'::regclass);


--
-- Name: modulhandbuch id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modulhandbuch ALTER COLUMN id SET DEFAULT nextval('public.modulhandbuch_id_seq'::regclass);


--
-- Name: phase_submissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phase_submissions ALTER COLUMN id SET DEFAULT nextval('public.phase_submissions_id_seq'::regclass);


--
-- Name: planungs_templates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planungs_templates ALTER COLUMN id SET DEFAULT nextval('public.planungs_templates_id_seq'::regclass);


--
-- Name: planungsphasen id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planungsphasen ALTER COLUMN id SET DEFAULT nextval('public.planungsphasen_id_seq'::regclass);


--
-- Name: pruefungsordnung id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pruefungsordnung ALTER COLUMN id SET DEFAULT nextval('public.pruefungsordnung_id_seq'::regclass);


--
-- Name: rolle id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rolle ALTER COLUMN id SET DEFAULT nextval('public.rolle_id_seq'::regclass);


--
-- Name: semester id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.semester ALTER COLUMN id SET DEFAULT nextval('public.semester_id_seq'::regclass);


--
-- Name: semester_auftrag id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.semester_auftrag ALTER COLUMN id SET DEFAULT nextval('public.semester_auftrag_id_seq'::regclass);


--
-- Name: semesterplanung id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.semesterplanung ALTER COLUMN id SET DEFAULT nextval('public.semesterplanung_id_seq'::regclass);


--
-- Name: sprache id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sprache ALTER COLUMN id SET DEFAULT nextval('public.sprache_id_seq'::regclass);


--
-- Name: studiengang id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studiengang ALTER COLUMN id SET DEFAULT nextval('public.studiengang_id_seq'::regclass);


--
-- Name: template_module id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.template_module ALTER COLUMN id SET DEFAULT nextval('public.template_module_id_seq'::regclass);


--
-- Name: wunsch_freie_tage id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wunsch_freie_tage ALTER COLUMN id SET DEFAULT nextval('public.wunsch_freie_tage_id_seq'::regclass);


--
-- Data for Name: archivierte_planungen; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.archivierte_planungen (original_planung_id, planungphase_id, professor_id, professor_name, semester_id, semester_name, phase_name, status_bei_archivierung, archiviert_am, archiviert_grund, archiviert_von, planung_daten, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_log (id, benutzer_id, aktion, tabelle, datensatz_id, alte_werte, neue_werte, ip_adresse, "timestamp") FROM stdin;
\.


--
-- Data for Name: auftrag; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auftrag (id, name, beschreibung, standard_sws, ist_aktiv, sortierung, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: benachrichtigung; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.benachrichtigung (id, empfaenger_id, typ, titel, nachricht, gelesen, erstellt_am, gelesen_am) FROM stdin;
1	1	system	Willkommen!	Willkommen im Dekanat-System!	t	2025-10-27 18:09:59.526396	2025-10-27 18:27:52.401378
2	1	planung_eingereicht	Neue Planung eingereicht	Prof. Müller hat eine Semesterplanung für WS2025 eingereicht.	f	2025-10-27 18:09:59.526415	\N
3	1	erinnerung	Erinnerung	Bitte überprüfen Sie die offenen Planungen.	f	2025-10-27 18:09:59.526417	\N
4	54	planung_eingereicht	Planung für WS2025 eingereicht	Ihre Semesterplanung für WS2025 wurde eingereicht und wartet auf Freigabe.	f	2025-11-01 17:58:43.397081	\N
5	1	planung_eingereicht	Neue Planung von Test Professor	Test Professor hat eine Semesterplanung für WS2025 eingereicht.	f	2025-11-01 17:58:43.429391	\N
6	54	planung_freigegeben	Planung für WS2025 freigegeben	Ihre Semesterplanung für WS2025 wurde freigegeben.	f	2025-11-01 18:37:44.259939	\N
\.


--
-- Data for Name: benutzer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.benutzer (id, email, username, password_hash, rolle_id, dozent_id, vorname, nachname, aktiv, letzter_login, created_at, updated_at) FROM stdin;
1	dekan@hochschule.de	dekan	scrypt:32768:8:1$ZfepLGce2LimdSjO$ac2e5d854da2f49755d74637e5dac4426d7fd955258d02d7074607834d7cbe226b94384d69d196de51114d75c77f5c0803fa0035a41369c7857a96cd51f5246c	1	\N	Maximilian	Müller	t	2025-11-06 13:14:13.708749	2025-10-15 14:45:51	2025-11-06 13:14:13.710244
2	alexanderkoch.(lehrbeauftragte/r)@hochschule.de	alexanderkoch.(lehrbeauftragte/r)	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	2	27	Alexander Koch	(Lehrbeauftragte/r)	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
3	n.n..(lehrbeauftragter)@hochschule.de	n.n..(lehrbeauftragter)	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	3	18	N.N.	(Lehrbeauftragter)	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
4	n.n..3d@hochschule.de	n.n..3d	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	3	19	N.N.	3D	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
5	henning.ahlf@hochschule.de	henning.ahlf	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	2	32	Henning	Ahlf	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
6	laura.anderle@hochschule.de	laura.anderle	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	2	11	Laura	Anderle	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
7	katja.becker@hochschule.de	katja.becker	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	2	2	Katja	Becker	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
8	-ing.sebastian.buettner@hochschule.de	-ing.sebastian.buettner	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	2	28	-Ing. Sebastian	Büttner	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
9	sebastian.buettner@hochschule.de	sebastian.buettner	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	2	5	Sebastian	Büttner	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
10	wolfram.conen@hochschule.de	wolfram.conen	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	2	1	Wolfram	Conen	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
11	andreas.cramer@hochschule.de	andreas.cramer	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	2	21	Andreas	Cramer	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
12	lehrendedesstudiengangsinformatikund.design@hochschule.de	lehrendedesstudiengangsinformatikund.design	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	3	3	Lehrende des Studiengangs Informatik und	Design	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
13	studiengangsbeauftrage/rinformatikund.design@hochschule.de	studiengangsbeauftrage/rinformatikund.design	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	3	4	Studiengangsbeauftrage/r Informatik und	Design	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
14	studiengangsbeauftragte/rinformatikund.design@hochschule.de	studiengangsbeauftragte/rinformatikund.design	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	3	10	Studiengangsbeauftragte/r Informatik und	Design	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
15	christian.dietrich@hochschule.de	christian.dietrich	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	2	30	Christian	Dietrich	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
16	alleprofessorinnenprofessorender.fachgruppe@hochschule.de	alleprofessorinnenprofessorender.fachgruppe	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	3	50	Alle Professorinnen Professoren der	Fachgruppe	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
17	alleprofessorinnenundprofessorender.fachgruppe@hochschule.de	alleprofessorinnenundprofessorender.fachgruppe	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	3	13	Alle Professorinnen und Professoren der	Fachgruppe	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
18	volker.goerick@hochschule.de	volker.goerick	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	3	37	Volker	Goerick	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
19	ulrike.griefahn@hochschule.de	ulrike.griefahn	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	2	23	Ulrike	Griefahn	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
20	dieter.hannemann@hochschule.de	dieter.hannemann	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	2	40	Dieter	Hannemann	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
21	alleprofessorenderfachgruppe.informatik@hochschule.de	alleprofessorenderfachgruppe.informatik	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	3	38	Alle Professoren der Fachgruppe	Informatik	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
22	studiengangsbeauftragte/r.informatik@hochschule.de	studiengangsbeauftragte/r.informatik	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	3	20	Studiengangsbeauftragte/r	Informatik	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
23	alleprofessorendesmaster-studiengangs.internet-@hochschule.de	alleprofessorendesmaster-studiengangs.internet-	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	3	46	Alle Professoren des Master-Studiengangs	Internet-	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
24	markus.jelonek@hochschule.de	markus.jelonek	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	2	9	Markus	Jelonek	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
25	henningahlf,prof.dr.siegbert.kern@hochschule.de	henningahlf,prof.dr.siegbert.kern	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	2	34	Henning Ahlf, Prof. Dr. Siegbert	Kern	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
26	siegbert.kern@hochschule.de	siegbert.kern	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	2	31	Siegbert	Kern	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
27	lehrbeauftragte/r@hochschule.de	lehrbeauftragte/r	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	3	29	\N	Lehrbeauftragte/r	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
28	ulrikegriefahn/.lehrbeauftragte/r@hochschule.de	ulrikegriefahn/.lehrbeauftragte/r	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	2	39	Ulrike Griefahn /	Lehrbeauftragte/r	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
29	lehrbeauftragter@hochschule.de	lehrbeauftragter	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	3	42	\N	Lehrbeauftragter	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
30	uwegruenefeld/.lehrbeauftragter@hochschule.de	uwegruenefeld/.lehrbeauftragter	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	3	43	Uwe Grünefeld /	Lehrbeauftragter	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
31	marcel.luis@hochschule.de	marcel.luis	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	2	7	Marcel	Luis	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
32	gregor.lux@hochschule.de	gregor.lux	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	2	8	Gregor	Lux	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
33	detlef.mansel@hochschule.de	detlef.mansel	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	2	22	Detlef	Mansel	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
34	alleprofessorender.medieninformatik@hochschule.de	alleprofessorender.medieninformatik	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	3	48	Alle Professoren der	Medieninformatik	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
35	lehrendeder.medieninformatik@hochschule.de	lehrendeder.medieninformatik	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	3	45	Lehrende der	Medieninformatik	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
36	studiengangsbeauftrage/r.medieninformatik@hochschule.de	studiengangsbeauftrage/r.medieninformatik	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	3	47	Studiengangsbeauftrage/r	Medieninformatik	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
37	studiengangsbeauftragte/r.medieninformatik@hochschule.de	studiengangsbeauftragte/r.medieninformatik	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	3	44	Studiengangsbeauftragte/r	Medieninformatik	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
38	henningahlf,prof.dr.leif.meier@hochschule.de	henningahlf,prof.dr.leif.meier	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	2	52	Henning Ahlf, Prof. Dr. Leif	Meier	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
39	leif.meier@hochschule.de	leif.meier	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	2	36	Leif	Meier	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
40	christopher.morasch@hochschule.de	christopher.morasch	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	2	51	Christopher	Morasch	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
41	siegbertkern,.n.n.@hochschule.de	siegbertkern,.n.n.	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	2	33	Siegbert Kern,	N.N.	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
42	n.n.3d@hochschule.de	n.n.3d	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	3	14	\N	N.N.3D	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
43	(tunn)norbert.pohlmann@hochschule.de	(tunn)norbert.pohlmann	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	2	25	(TU NN) Norbert	Pohlmann	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
44	n.n..swt@hochschule.de	n.n..swt	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	3	41	N.N.	SWT	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
45	michael.schmeing@hochschule.de	michael.schmeing	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	2	15	Michael	Schmeing	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
46	dozent:indes.sprachenzentrums@hochschule.de	dozent:indes.sprachenzentrums	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	3	17	Dozent:in des	Sprachenzentrums	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
47	leitungdes.sprachenzentrums@hochschule.de	leitungdes.sprachenzentrums	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	3	16	Leitung des	Sprachenzentrums	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
48	studiengangsbeauftragte/rdesjeweiligen.studiengangs@hochschule.de	studiengangsbeauftragte/rdesjeweiligen.studiengangs	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	3	12	Studiengangsbeauftragte/r des jeweiligen	Studiengangs	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
49	-ing.dipl.inform.hartmut.surmann@hochschule.de	-ing.dipl.inform.hartmut.surmann	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	2	24	-Ing. Dipl. Inform. Hartmut	Surmann	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
50	tobias.urban@hochschule.de	tobias.urban	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	2	35	Tobias	Urban	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
51	studiengangsbeauftragte/r.wirtschaftsinformatik@hochschule.de	studiengangsbeauftragte/r.wirtschaftsinformatik	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	3	26	Studiengangsbeauftragte/r	Wirtschaftsinformatik	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
52	katja.zeume@hochschule.de	katja.zeume	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	2	6	Katja	Zeume	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
53	alleprofessorinnenundprofessoren.der@hochschule.de	alleprofessorinnenundprofessoren.der	pbkdf2:sha256:1000000$AwDpXpPJ2Gdb7G4g$9de313c605e16df63b23caa13e9aa083eb7f040a875b4b2f389a9a0d449c5e6b	3	49	Alle Professorinnen und Professoren	der	t	\N	2025-10-15 14:45:51	2025-10-15 14:45:51
54	prof.test@hochschule.de	prof.test	pbkdf2:sha256:1000000$kvPiJ2DsK04NZTyI$8891d4bcea94747a95dba5f276edc699d0819cb4a668fc57294c88f6cf4ba958	2	\N	Test	Professor	t	2025-11-06 13:12:34.522489	2025-10-30 20:36:37.318177	2025-11-06 13:12:34.523509
\.


--
-- Data for Name: deputats_betreuung; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.deputats_betreuung (id, deputatsabrechnung_id, student_name, student_vorname, titel_arbeit, betreuungsart, status, beginn_datum, ende_datum, sws, created_at) FROM stdin;
\.


--
-- Data for Name: deputats_einstellungen; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.deputats_einstellungen (id, sws_bachelor_arbeit, sws_master_arbeit, sws_doktorarbeit, sws_seminar_ba, sws_seminar_ma, sws_projekt_ba, sws_projekt_ma, max_sws_praxisseminar, max_sws_projektveranstaltung, max_sws_seminar_master, max_sws_betreuung, warn_ermaessigung_ueber, default_netto_lehrverpflichtung, ist_aktiv, beschreibung, created_at, updated_at, erstellt_von) FROM stdin;
\.


--
-- Data for Name: deputats_ermaessigung; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.deputats_ermaessigung (id, deputatsabrechnung_id, bezeichnung, sws, quelle, semester_auftrag_id, created_at) FROM stdin;
\.


--
-- Data for Name: deputats_lehrexport; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.deputats_lehrexport (id, deputatsabrechnung_id, fachbereich, fach, sws, created_at) FROM stdin;
\.


--
-- Data for Name: deputats_lehrtaetigkeit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.deputats_lehrtaetigkeit (id, deputatsabrechnung_id, bezeichnung, kategorie, sws, wochentag, wochentage, ist_block, quelle, geplantes_modul_id, created_at) FROM stdin;
\.


--
-- Data for Name: deputats_vertretung; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.deputats_vertretung (id, deputatsabrechnung_id, art, vertretene_person, fach_professor, sws, created_at) FROM stdin;
\.


--
-- Data for Name: deputatsabrechnung; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.deputatsabrechnung (id, planungsphase_id, benutzer_id, netto_lehrverpflichtung, status, bemerkungen, eingereicht_am, genehmigt_von, genehmigt_am, abgelehnt_am, ablehnungsgrund, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: dozent; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dozent (id, titel, vorname, nachname, name_komplett, email, fachbereich, aktiv, created_at) FROM stdin;
1	Prof. Dr.	Wolfram	Conen	Prof. Dr. Wolfram Conen	leif.meier@w-hs.de		t	2025-10-09 15:29:11
2	Prof.	Katja	Becker	Prof. Katja Becker	\N	\N	t	2025-10-09 15:29:11
3	\N	Lehrende des Studiengangs Informatik und	Design	Lehrende des Studiengangs Informatik und Design	\N	\N	t	2025-10-09 15:29:11
4	\N	Studiengangsbeauftrage/r Informatik und	Design	Studiengangsbeauftrage/r Informatik und Design	\N	\N	t	2025-10-09 15:29:11
5	Prof. Dr.	Sebastian	Büttner	Prof. Dr. Sebastian Büttner	\N	\N	t	2025-10-09 15:29:11
6	Prof. Dr.	Katja	Zeume	Prof. Dr. Katja Zeume	\N	\N	t	2025-10-09 15:29:11
7	Prof. Dr.	Marcel	Luis	Prof. Dr. Marcel Luis	\N	\N	t	2025-10-09 15:29:11
8	Prof. Dr.	Gregor	Lux	Prof. Dr. Gregor Lux	\N	\N	t	2025-10-09 15:29:11
9	Prof. Dr.	Markus	Jelonek	Prof. Dr. Markus Jelonek	\N	\N	t	2025-10-09 15:29:11
10	\N	Studiengangsbeauftragte/r Informatik und	Design	Studiengangsbeauftragte/r Informatik und Design	\N	\N	t	2025-10-09 15:29:11
11	Prof. Dr.	Laura	Anderle	Prof. Dr. Laura Anderle	\N	\N	t	2025-10-09 15:29:11
12	\N	Studiengangsbeauftragte/r des jeweiligen	Studiengangs	Studiengangsbeauftragte/r des jeweiligen Studiengangs	\N	\N	t	2025-10-09 15:29:11
13	\N	Alle Professorinnen und Professoren der	Fachgruppe	Alle Professorinnen und Professoren der Fachgruppe	\N	\N	t	2025-10-09 15:29:11
14	\N	\N	N.N.3D	N.N.3D	\N	\N	t	2025-10-09 15:29:11
15	Prof. Dr.	Michael	Schmeing	Prof. Dr. Michael Schmeing	\N	\N	t	2025-10-09 15:29:11
16	\N	Leitung des	Sprachenzentrums	Leitung des Sprachenzentrums	\N	\N	t	2025-10-09 15:29:11
17	\N	Dozent:in des	Sprachenzentrums	Dozent:in des Sprachenzentrums	\N	\N	t	2025-10-09 15:29:11
18	\N	N.N.	(Lehrbeauftragter)	N.N. (Lehrbeauftragter)	\N	\N	t	2025-10-09 15:29:11
19	\N	N.N.	3D	N.N. 3D	\N	\N	t	2025-10-09 15:29:11
20	\N	Studiengangsbeauftragte/r	Informatik	Studiengangsbeauftragte/r Informatik	\N	\N	t	2025-10-09 15:29:15
21	Prof. Dr.	Andreas	Cramer	Prof. Dr. Andreas Cramer	\N	\N	t	2025-10-09 15:29:15
22	Prof. Dr.	Detlef	Mansel	Prof. Dr. Detlef Mansel	\N	\N	t	2025-10-09 15:29:15
23	Prof. Dr.	Ulrike	Griefahn	Prof. Dr. Ulrike Griefahn	\N	\N	t	2025-10-09 15:29:15
24	Prof. Dr.	-Ing. Dipl. Inform. Hartmut	Surmann	Prof. Dr.-Ing. Dipl. Inform. Hartmut Surmann	\N	\N	t	2025-10-09 15:29:15
25	Prof. Dr.	(TU NN) Norbert	Pohlmann	Prof. Dr. (TU NN) Norbert Pohlmann	\N	\N	t	2025-10-09 15:29:15
26	\N	Studiengangsbeauftragte/r	Wirtschaftsinformatik	Studiengangsbeauftragte/r Wirtschaftsinformatik	\N	\N	t	2025-10-09 15:29:15
27	Prof. Dr.	Alexander Koch	(Lehrbeauftragte/r)	Prof. Dr. Alexander Koch (Lehrbeauftragte/r)	\N	\N	t	2025-10-09 15:29:15
28	Prof. Dr.	-Ing. Sebastian	Büttner	Prof. Dr.-Ing. Sebastian Büttner	\N	\N	t	2025-10-09 15:29:15
29	\N	\N	Lehrbeauftragte/r	Lehrbeauftragte/r	\N	\N	t	2025-10-09 15:29:15
30	Prof. Dr.	Christian	Dietrich	Prof. Dr. Christian Dietrich	\N	\N	t	2025-10-09 15:29:15
31	Prof. Dr.	Siegbert	Kern	Prof. Dr. Siegbert Kern	\N	\N	t	2025-10-09 15:29:15
32	Prof. Dr.	Henning	Ahlf	Prof. Dr. Henning Ahlf	\N	\N	t	2025-10-09 15:29:15
33	Prof. Dr.	Siegbert Kern,	N.N.	Prof. Dr. Siegbert Kern, N.N.	\N	\N	t	2025-10-09 15:29:15
34	Prof. Dr.	Henning Ahlf, Prof. Dr. Siegbert	Kern	Prof. Dr. Henning Ahlf, Prof. Dr. Siegbert Kern	\N	\N	t	2025-10-09 15:29:15
35	Prof. Dr.	Tobias	Urban	Prof. Dr. Tobias Urban	\N	\N	t	2025-10-09 15:29:15
36	Prof. Dr.	Leif	Meier	Prof. Dr. Leif Meier	\N	\N	t	2025-10-09 15:29:15
37	\N	Volker	Goerick	Volker Goerick	\N	\N	t	2025-10-09 15:29:15
38	\N	Alle Professoren der Fachgruppe	Informatik	Alle Professoren der Fachgruppe Informatik	\N	\N	t	2025-10-09 15:29:20
39	Prof. Dr.	Ulrike Griefahn /	Lehrbeauftragte/r	Prof. Dr. Ulrike Griefahn / Lehrbeauftragte/r	\N	\N	t	2025-10-09 15:29:20
40	Prof. Dr.	Dieter	Hannemann	Prof. Dr. Dieter Hannemann	\N	\N	t	2025-10-09 15:29:20
41	\N	N.N.	SWT	N.N. SWT	\N	\N	t	2025-10-09 15:29:20
42	\N	\N	Lehrbeauftragter	Lehrbeauftragter	\N	\N	t	2025-10-09 15:29:20
43	Dr.	Uwe Grünefeld /	Lehrbeauftragter	Dr. Uwe Grünefeld / Lehrbeauftragter	\N	\N	t	2025-10-09 15:29:20
44	\N	Studiengangsbeauftragte/r	Medieninformatik	Studiengangsbeauftragte/r Medieninformatik	\N	\N	t	2025-10-09 15:29:20
45	\N	Lehrende der	Medieninformatik	Lehrende der Medieninformatik	\N	\N	t	2025-10-09 15:29:20
46	\N	Alle Professoren des Master-Studiengangs	Internet-	Alle Professoren des Master-Studiengangs Internet-	\N	\N	t	2025-10-09 15:29:22
47	\N	Studiengangsbeauftrage/r	Medieninformatik	Studiengangsbeauftrage/r Medieninformatik	\N	\N	t	2025-10-09 15:29:26
48	\N	Alle Professoren der	Medieninformatik	Alle Professoren der Medieninformatik	\N	\N	t	2025-10-09 15:29:26
49	\N	Alle Professorinnen und Professoren	der	Alle Professorinnen und Professoren der	\N	\N	t	2025-10-09 15:29:26
50	\N	Alle Professorinnen Professoren der	Fachgruppe	Alle Professorinnen Professoren der Fachgruppe	\N	\N	t	2025-10-09 15:29:33
51	Prof. Dr.	Christopher	Morasch	Prof. Dr. Christopher Morasch	\N	\N	t	2025-10-09 15:29:33
52	Prof. Dr.	Henning Ahlf, Prof. Dr. Leif	Meier	Prof. Dr. Henning Ahlf, Prof. Dr. Leif Meier	\N	\N	t	2025-10-09 15:29:33
53	Prof	Mohammad	Alboush	Prof Mohammad Alboush	mohammad.alboush@w-hs.de	Inforamtik	t	2025-11-02 23:09:26.901001
\.


--
-- Data for Name: geplante_module; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.geplante_module (id, semesterplanung_id, modul_id, po_id, anzahl_vorlesungen, anzahl_uebungen, anzahl_praktika, anzahl_seminare, sws_vorlesung, sws_uebung, sws_praktikum, sws_seminar, sws_gesamt, mitarbeiter_ids, anmerkungen, raumbedarf, raum_vorlesung, raum_uebung, raum_praktikum, raum_seminar, kapazitaet_vorlesung, kapazitaet_uebung, kapazitaet_praktikum, kapazitaet_seminar, created_at) FROM stdin;
\.


--
-- Data for Name: lehrform; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lehrform (id, bezeichnung, kuerzel) FROM stdin;
1	Vorlesung	V
2	Übung	Ü
3	Praktikum	P
4	Labor	L
5	Seminar	S
6	Projekt	Pr
7	Tutorium	T
\.


--
-- Data for Name: modul; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.modul (id, kuerzel, po_id, bezeichnung_de, bezeichnung_en, untertitel, leistungspunkte, turnus, "gruppengröße", teilnehmerzahl, anmeldemodalitaeten, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: modul_abhÃ¤ngigkeit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."modul_abhÃ¤ngigkeit" (id, modul_id, voraussetzung_modul_id, po_id, typ) FROM stdin;
\.


--
-- Data for Name: modul_arbeitsaufwand; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.modul_arbeitsaufwand (modul_id, po_id, kontaktzeit_stunden, selbststudium_stunden, pruefungsvorbereitung_stunden, gesamt_stunden) FROM stdin;
\.


--
-- Data for Name: modul_audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.modul_audit_log (id, modul_id, po_id, geaendert_von, aktion, alt_dozent_id, neu_dozent_id, alte_rolle, neue_rolle, bemerkung, created_at) FROM stdin;
\.


--
-- Data for Name: modul_dozent; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.modul_dozent (id, modul_id, po_id, dozent_id, rolle, vertreter_id, zweitpruefer_id) FROM stdin;
\.


--
-- Data for Name: modul_lehrform; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.modul_lehrform (id, modul_id, po_id, lehrform_id, sws) FROM stdin;
\.


--
-- Data for Name: modul_lernergebnisse; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.modul_lernergebnisse (modul_id, po_id, lernziele, kompetenzen, inhalt) FROM stdin;
\.


--
-- Data for Name: modul_literatur; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.modul_literatur (id, modul_id, po_id, titel, autoren, verlag, jahr, isbn, typ, pflichtliteratur, sortierung) FROM stdin;
\.


--
-- Data for Name: modul_pruefung; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.modul_pruefung (modul_id, po_id, pruefungsform, pruefungsdauer_minuten, pruefungsleistungen, benotung) FROM stdin;
\.


--
-- Data for Name: modul_seiten; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.modul_seiten (modul_id, po_id, modulhandbuch_id, seite_von, seite_bis) FROM stdin;
\.


--
-- Data for Name: modul_sprache; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.modul_sprache (modul_id, po_id, sprache_id) FROM stdin;
\.


--
-- Data for Name: modul_studiengang; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.modul_studiengang (id, modul_id, po_id, studiengang_id, semester, pflicht, wahlpflicht) FROM stdin;
\.


--
-- Data for Name: modul_voraussetzungen; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.modul_voraussetzungen (modul_id, po_id, formal, empfohlen, inhaltlich) FROM stdin;
\.


--
-- Data for Name: modulhandbuch; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.modulhandbuch (id, dateiname, studiengang_id, po_id, version, anzahl_seiten, anzahl_module, import_datum, hash) FROM stdin;
\.


--
-- Data for Name: phase_submissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phase_submissions (planungphase_id, professor_id, planung_id, eingereicht_am, status, freigegeben_am, freigegeben_von, abgelehnt_am, abgelehnt_von, abgelehnt_grund, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: planungs_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.planungs_templates (id, benutzer_id, semester_typ, name, beschreibung, ist_aktiv, wunsch_freie_tage, anmerkungen, raumbedarf, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: planungsphasen; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.planungsphasen (semester_id, name, startdatum, enddatum, ist_aktiv, geschlossen_am, geschlossen_von, geschlossen_grund, anzahl_einreichungen, anzahl_genehmigt, anzahl_abgelehnt, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: pruefungsordnung; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pruefungsordnung (id, po_jahr, gueltig_von, gueltig_bis, beschreibung, created_at, updated_at) FROM stdin;
1	PO2023	2023-10-01	\N	\N	2025-10-09 15:29:06	2025-10-09 15:29:06
\.


--
-- Data for Name: rolle; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rolle (id, name, beschreibung, created_at) FROM stdin;
1	dekan	Dekan - Vollzugriff	2025-10-15 14:45:51
2	professor	Professor - Eigene Planung + Module	2025-10-15 14:45:51
3	lehrbeauftragter	Lehrbeauftragter - Eigene Planung	2025-10-15 14:45:51
\.


--
-- Data for Name: semester; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.semester (id, bezeichnung, kuerzel, start_datum, ende_datum, vorlesungsbeginn, vorlesungsende, ist_aktiv, ist_planungsphase, created_at) FROM stdin;
1	Wintersemester 2025/2026	WS2025	2025-10-01	2026-03-31	2025-10-15	2026-02-15	t	t	2025-10-15 14:45:51
\.


--
-- Data for Name: semester_auftrag; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.semester_auftrag (id, semester_id, auftrag_id, dozent_id, sws, status, beantragt_von, genehmigt_von, genehmigt_am, anmerkung, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: semesterplanung; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.semesterplanung (id, semester_id, benutzer_id, planungsphase_id, status, anmerkungen, raumbedarf, room_requirements, special_requests, gesamt_sws, eingereicht_am, freigegeben_von, freigegeben_am, abgelehnt_am, ablehnungsgrund, created_at, updated_at) FROM stdin;
1	1	1	\N	entwurf	\N	\N	\N	\N	16	\N	\N	\N	\N	\N	2025-10-27 16:27:29.04469	2025-10-27 16:33:44.107223
2	1	54	\N	freigegeben	\N	\N	\N	\N	4	2025-11-01 17:58:43.360398	1	2025-11-01 18:37:44.23583	\N	\N	2025-11-01 15:19:30.964431	2025-11-01 18:37:44.236835
\.


--
-- Data for Name: sprache; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sprache (id, bezeichnung, iso_code) FROM stdin;
1	Deutsch	de
2	Englisch	en
3	Deutsch/Englisch	de-en
\.


--
-- Data for Name: studiengang; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.studiengang (id, kuerzel, bezeichnung, abschluss, fachbereich, regelstudienzeit, ects_gesamt, aktiv, created_at) FROM stdin;
\.


--
-- Data for Name: template_module; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.template_module (id, template_id, modul_id, po_id, anzahl_vorlesungen, anzahl_uebungen, anzahl_praktika, anzahl_seminare, mitarbeiter_ids, anmerkungen, raumbedarf, raum_vorlesung, raum_uebung, raum_praktikum, raum_seminar, kapazitaet_vorlesung, kapazitaet_uebung, kapazitaet_praktikum, kapazitaet_seminar, created_at) FROM stdin;
\.


--
-- Data for Name: wunsch_freie_tage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wunsch_freie_tage (id, semesterplanung_id, wochentag, zeitraum, prioritaet, bemerkung, grund) FROM stdin;
\.


--
-- Name: archivierte_planungen_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.archivierte_planungen_id_seq', 1, false);


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 1, false);


--
-- Name: auftrag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auftrag_id_seq', 1, false);


--
-- Name: benachrichtigung_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.benachrichtigung_id_seq', 6, true);


--
-- Name: benutzer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.benutzer_id_seq', 54, true);


--
-- Name: deputats_betreuung_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.deputats_betreuung_id_seq', 1, false);


--
-- Name: deputats_einstellungen_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.deputats_einstellungen_id_seq', 1, false);


--
-- Name: deputats_ermaessigung_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.deputats_ermaessigung_id_seq', 1, false);


--
-- Name: deputats_lehrexport_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.deputats_lehrexport_id_seq', 1, false);


--
-- Name: deputats_lehrtaetigkeit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.deputats_lehrtaetigkeit_id_seq', 1, false);


--
-- Name: deputats_vertretung_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.deputats_vertretung_id_seq', 1, false);


--
-- Name: deputatsabrechnung_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.deputatsabrechnung_id_seq', 1, false);


--
-- Name: dozent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dozent_id_seq', 53, true);


--
-- Name: geplante_module_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.geplante_module_id_seq', 1, false);


--
-- Name: lehrform_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.lehrform_id_seq', 7, true);


--
-- Name: modul_abhÃ¤ngigkeit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."modul_abhÃ¤ngigkeit_id_seq"', 1, false);


--
-- Name: modul_audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.modul_audit_log_id_seq', 1, false);


--
-- Name: modul_dozent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.modul_dozent_id_seq', 1, false);


--
-- Name: modul_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.modul_id_seq', 1, false);


--
-- Name: modul_lehrform_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.modul_lehrform_id_seq', 1, false);


--
-- Name: modul_literatur_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.modul_literatur_id_seq', 1, false);


--
-- Name: modul_studiengang_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.modul_studiengang_id_seq', 1, false);


--
-- Name: modulhandbuch_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.modulhandbuch_id_seq', 1, false);


--
-- Name: phase_submissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phase_submissions_id_seq', 1, false);


--
-- Name: planungs_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.planungs_templates_id_seq', 1, false);


--
-- Name: planungsphasen_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.planungsphasen_id_seq', 1, false);


--
-- Name: pruefungsordnung_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pruefungsordnung_id_seq', 1, true);


--
-- Name: rolle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rolle_id_seq', 3, true);


--
-- Name: semester_auftrag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.semester_auftrag_id_seq', 1, false);


--
-- Name: semester_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.semester_id_seq', 1, true);


--
-- Name: semesterplanung_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.semesterplanung_id_seq', 2, true);


--
-- Name: sprache_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sprache_id_seq', 3, true);


--
-- Name: studiengang_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.studiengang_id_seq', 1, false);


--
-- Name: template_module_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.template_module_id_seq', 1, false);


--
-- Name: wunsch_freie_tage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.wunsch_freie_tage_id_seq', 1, false);


--
-- Name: archivierte_planungen archivierte_planungen_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.archivierte_planungen
    ADD CONSTRAINT archivierte_planungen_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: auftrag auftrag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auftrag
    ADD CONSTRAINT auftrag_pkey PRIMARY KEY (id);


--
-- Name: benachrichtigung benachrichtigung_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.benachrichtigung
    ADD CONSTRAINT benachrichtigung_pkey PRIMARY KEY (id);


--
-- Name: benutzer benutzer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.benutzer
    ADD CONSTRAINT benutzer_pkey PRIMARY KEY (id);


--
-- Name: deputats_betreuung deputats_betreuung_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deputats_betreuung
    ADD CONSTRAINT deputats_betreuung_pkey PRIMARY KEY (id);


--
-- Name: deputats_einstellungen deputats_einstellungen_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deputats_einstellungen
    ADD CONSTRAINT deputats_einstellungen_pkey PRIMARY KEY (id);


--
-- Name: deputats_ermaessigung deputats_ermaessigung_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deputats_ermaessigung
    ADD CONSTRAINT deputats_ermaessigung_pkey PRIMARY KEY (id);


--
-- Name: deputats_lehrexport deputats_lehrexport_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deputats_lehrexport
    ADD CONSTRAINT deputats_lehrexport_pkey PRIMARY KEY (id);


--
-- Name: deputats_lehrtaetigkeit deputats_lehrtaetigkeit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deputats_lehrtaetigkeit
    ADD CONSTRAINT deputats_lehrtaetigkeit_pkey PRIMARY KEY (id);


--
-- Name: deputats_vertretung deputats_vertretung_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deputats_vertretung
    ADD CONSTRAINT deputats_vertretung_pkey PRIMARY KEY (id);


--
-- Name: deputatsabrechnung deputatsabrechnung_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deputatsabrechnung
    ADD CONSTRAINT deputatsabrechnung_pkey PRIMARY KEY (id);


--
-- Name: dozent dozent_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dozent
    ADD CONSTRAINT dozent_pkey PRIMARY KEY (id);


--
-- Name: geplante_module geplante_module_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.geplante_module
    ADD CONSTRAINT geplante_module_pkey PRIMARY KEY (id);


--
-- Name: lehrform lehrform_bezeichnung_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lehrform
    ADD CONSTRAINT lehrform_bezeichnung_key UNIQUE (bezeichnung);


--
-- Name: lehrform lehrform_kuerzel_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lehrform
    ADD CONSTRAINT lehrform_kuerzel_key UNIQUE (kuerzel);


--
-- Name: lehrform lehrform_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lehrform
    ADD CONSTRAINT lehrform_pkey PRIMARY KEY (id);


--
-- Name: modul_abhÃ¤ngigkeit modul_abhÃ¤ngigkeit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."modul_abhÃ¤ngigkeit"
    ADD CONSTRAINT "modul_abhÃ¤ngigkeit_pkey" PRIMARY KEY (id);


--
-- Name: modul_arbeitsaufwand modul_arbeitsaufwand_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_arbeitsaufwand
    ADD CONSTRAINT modul_arbeitsaufwand_pkey PRIMARY KEY (modul_id, po_id);


--
-- Name: modul_audit_log modul_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_audit_log
    ADD CONSTRAINT modul_audit_log_pkey PRIMARY KEY (id);


--
-- Name: modul_dozent modul_dozent_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_dozent
    ADD CONSTRAINT modul_dozent_pkey PRIMARY KEY (id);


--
-- Name: modul_lehrform modul_lehrform_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_lehrform
    ADD CONSTRAINT modul_lehrform_pkey PRIMARY KEY (id);


--
-- Name: modul_lernergebnisse modul_lernergebnisse_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_lernergebnisse
    ADD CONSTRAINT modul_lernergebnisse_pkey PRIMARY KEY (modul_id, po_id);


--
-- Name: modul_literatur modul_literatur_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_literatur
    ADD CONSTRAINT modul_literatur_pkey PRIMARY KEY (id);


--
-- Name: modul modul_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul
    ADD CONSTRAINT modul_pkey PRIMARY KEY (id);


--
-- Name: modul_pruefung modul_pruefung_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_pruefung
    ADD CONSTRAINT modul_pruefung_pkey PRIMARY KEY (modul_id, po_id);


--
-- Name: modul_seiten modul_seiten_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_seiten
    ADD CONSTRAINT modul_seiten_pkey PRIMARY KEY (modul_id, po_id, modulhandbuch_id);


--
-- Name: modul_sprache modul_sprache_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_sprache
    ADD CONSTRAINT modul_sprache_pkey PRIMARY KEY (modul_id, po_id, sprache_id);


--
-- Name: modul_studiengang modul_studiengang_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_studiengang
    ADD CONSTRAINT modul_studiengang_pkey PRIMARY KEY (id);


--
-- Name: modul_voraussetzungen modul_voraussetzungen_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_voraussetzungen
    ADD CONSTRAINT modul_voraussetzungen_pkey PRIMARY KEY (modul_id, po_id);


--
-- Name: modulhandbuch modulhandbuch_dateiname_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modulhandbuch
    ADD CONSTRAINT modulhandbuch_dateiname_key UNIQUE (dateiname);


--
-- Name: modulhandbuch modulhandbuch_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modulhandbuch
    ADD CONSTRAINT modulhandbuch_hash_key UNIQUE (hash);


--
-- Name: modulhandbuch modulhandbuch_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modulhandbuch
    ADD CONSTRAINT modulhandbuch_pkey PRIMARY KEY (id);


--
-- Name: phase_submissions phase_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phase_submissions
    ADD CONSTRAINT phase_submissions_pkey PRIMARY KEY (id);


--
-- Name: planungs_templates planungs_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planungs_templates
    ADD CONSTRAINT planungs_templates_pkey PRIMARY KEY (id);


--
-- Name: planungsphasen planungsphasen_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planungsphasen
    ADD CONSTRAINT planungsphasen_pkey PRIMARY KEY (id);


--
-- Name: pruefungsordnung pruefungsordnung_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pruefungsordnung
    ADD CONSTRAINT pruefungsordnung_pkey PRIMARY KEY (id);


--
-- Name: pruefungsordnung pruefungsordnung_po_jahr_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pruefungsordnung
    ADD CONSTRAINT pruefungsordnung_po_jahr_key UNIQUE (po_jahr);


--
-- Name: rolle rolle_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rolle
    ADD CONSTRAINT rolle_pkey PRIMARY KEY (id);


--
-- Name: semester_auftrag semester_auftrag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.semester_auftrag
    ADD CONSTRAINT semester_auftrag_pkey PRIMARY KEY (id);


--
-- Name: semester semester_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.semester
    ADD CONSTRAINT semester_pkey PRIMARY KEY (id);


--
-- Name: semesterplanung semesterplanung_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.semesterplanung
    ADD CONSTRAINT semesterplanung_pkey PRIMARY KEY (id);


--
-- Name: sprache sprache_bezeichnung_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sprache
    ADD CONSTRAINT sprache_bezeichnung_key UNIQUE (bezeichnung);


--
-- Name: sprache sprache_iso_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sprache
    ADD CONSTRAINT sprache_iso_code_key UNIQUE (iso_code);


--
-- Name: sprache sprache_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sprache
    ADD CONSTRAINT sprache_pkey PRIMARY KEY (id);


--
-- Name: studiengang studiengang_kuerzel_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studiengang
    ADD CONSTRAINT studiengang_kuerzel_key UNIQUE (kuerzel);


--
-- Name: studiengang studiengang_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studiengang
    ADD CONSTRAINT studiengang_pkey PRIMARY KEY (id);


--
-- Name: template_module template_module_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.template_module
    ADD CONSTRAINT template_module_pkey PRIMARY KEY (id);


--
-- Name: phase_submissions unique_professor_phase_approved; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phase_submissions
    ADD CONSTRAINT unique_professor_phase_approved UNIQUE (planungphase_id, professor_id, status);


--
-- Name: deputatsabrechnung uq_deputat_phase_benutzer; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deputatsabrechnung
    ADD CONSTRAINT uq_deputat_phase_benutzer UNIQUE (planungsphase_id, benutzer_id);


--
-- Name: geplante_module uq_planung_modul; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.geplante_module
    ADD CONSTRAINT uq_planung_modul UNIQUE (semesterplanung_id, modul_id);


--
-- Name: semesterplanung uq_semester_benutzer_phase; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.semesterplanung
    ADD CONSTRAINT uq_semester_benutzer_phase UNIQUE (semester_id, benutzer_id, planungsphase_id);


--
-- Name: planungs_templates uq_template_benutzer_semestertyp; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planungs_templates
    ADD CONSTRAINT uq_template_benutzer_semestertyp UNIQUE (benutzer_id, semester_typ);


--
-- Name: template_module uq_template_modul; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.template_module
    ADD CONSTRAINT uq_template_modul UNIQUE (template_id, modul_id);


--
-- Name: wunsch_freie_tage wunsch_freie_tage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wunsch_freie_tage
    ADD CONSTRAINT wunsch_freie_tage_pkey PRIMARY KEY (id);


--
-- Name: idx_dozent_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dozent_name ON public.dozent USING btree (nachname, vorname);


--
-- Name: idx_modul_dozent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_modul_dozent ON public.modul_dozent USING btree (modul_id, dozent_id);


--
-- Name: idx_modul_kuerzel; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_modul_kuerzel ON public.modul USING btree (kuerzel);


--
-- Name: idx_modul_po; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_modul_po ON public.modul USING btree (po_id);


--
-- Name: idx_modul_studiengang; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_modul_studiengang ON public.modul_studiengang USING btree (modul_id, studiengang_id);


--
-- Name: ix_audit_log_aktion; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_log_aktion ON public.audit_log USING btree (aktion);


--
-- Name: ix_audit_log_benutzer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_log_benutzer_id ON public.audit_log USING btree (benutzer_id);


--
-- Name: ix_audit_log_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_log_timestamp ON public.audit_log USING btree ("timestamp");


--
-- Name: ix_auftrag_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_auftrag_name ON public.auftrag USING btree (name);


--
-- Name: ix_benachrichtigung_empfaenger_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_benachrichtigung_empfaenger_id ON public.benachrichtigung USING btree (empfaenger_id);


--
-- Name: ix_benachrichtigung_gelesen; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_benachrichtigung_gelesen ON public.benachrichtigung USING btree (gelesen);


--
-- Name: ix_benutzer_dozent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_benutzer_dozent_id ON public.benutzer USING btree (dozent_id);


--
-- Name: ix_benutzer_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_benutzer_email ON public.benutzer USING btree (email);


--
-- Name: ix_benutzer_rolle_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_benutzer_rolle_id ON public.benutzer USING btree (rolle_id);


--
-- Name: ix_benutzer_username; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_benutzer_username ON public.benutzer USING btree (username);


--
-- Name: ix_deputat_benutzer_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_deputat_benutzer_status ON public.deputatsabrechnung USING btree (benutzer_id, status);


--
-- Name: ix_deputat_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_deputat_status ON public.deputatsabrechnung USING btree (status);


--
-- Name: ix_deputats_betreuung_deputatsabrechnung_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_deputats_betreuung_deputatsabrechnung_id ON public.deputats_betreuung USING btree (deputatsabrechnung_id);


--
-- Name: ix_deputats_ermaessigung_deputatsabrechnung_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_deputats_ermaessigung_deputatsabrechnung_id ON public.deputats_ermaessigung USING btree (deputatsabrechnung_id);


--
-- Name: ix_deputats_lehrexport_deputatsabrechnung_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_deputats_lehrexport_deputatsabrechnung_id ON public.deputats_lehrexport USING btree (deputatsabrechnung_id);


--
-- Name: ix_deputats_lehrtaetigkeit_deputatsabrechnung_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_deputats_lehrtaetigkeit_deputatsabrechnung_id ON public.deputats_lehrtaetigkeit USING btree (deputatsabrechnung_id);


--
-- Name: ix_deputats_vertretung_deputatsabrechnung_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_deputats_vertretung_deputatsabrechnung_id ON public.deputats_vertretung USING btree (deputatsabrechnung_id);


--
-- Name: ix_deputatsabrechnung_benutzer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_deputatsabrechnung_benutzer_id ON public.deputatsabrechnung USING btree (benutzer_id);


--
-- Name: ix_deputatsabrechnung_planungsphase_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_deputatsabrechnung_planungsphase_id ON public.deputatsabrechnung USING btree (planungsphase_id);


--
-- Name: ix_deputatsabrechnung_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_deputatsabrechnung_status ON public.deputatsabrechnung USING btree (status);


--
-- Name: ix_geplante_module_modul_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_geplante_module_modul_id ON public.geplante_module USING btree (modul_id);


--
-- Name: ix_geplante_module_semesterplanung_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_geplante_module_semesterplanung_id ON public.geplante_module USING btree (semesterplanung_id);


--
-- Name: ix_geplantes_modul_planung; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_geplantes_modul_planung ON public.geplante_module USING btree (semesterplanung_id);


--
-- Name: ix_modul_audit_log_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_modul_audit_log_created_at ON public.modul_audit_log USING btree (created_at);


--
-- Name: ix_modul_audit_log_modul_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_modul_audit_log_modul_id ON public.modul_audit_log USING btree (modul_id);


--
-- Name: ix_modul_audit_modul_datum; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_modul_audit_modul_datum ON public.modul_audit_log USING btree (modul_id, created_at);


--
-- Name: ix_modul_dozent_dozent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_modul_dozent_dozent_id ON public.modul_dozent USING btree (dozent_id);


--
-- Name: ix_modul_dozent_modul_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_modul_dozent_modul_id ON public.modul_dozent USING btree (modul_id);


--
-- Name: ix_modul_dozent_vertreter_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_modul_dozent_vertreter_id ON public.modul_dozent USING btree (vertreter_id);


--
-- Name: ix_modul_dozent_zweitpruefer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_modul_dozent_zweitpruefer_id ON public.modul_dozent USING btree (zweitpruefer_id);


--
-- Name: ix_modul_kuerzel; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_modul_kuerzel ON public.modul USING btree (kuerzel);


--
-- Name: ix_modul_lehrform_modul_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_modul_lehrform_modul_id ON public.modul_lehrform USING btree (modul_id);


--
-- Name: ix_modul_po_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_modul_po_id ON public.modul USING btree (po_id);


--
-- Name: ix_modul_studiengang_modul_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_modul_studiengang_modul_id ON public.modul_studiengang USING btree (modul_id);


--
-- Name: ix_modul_studiengang_studiengang_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_modul_studiengang_studiengang_id ON public.modul_studiengang USING btree (studiengang_id);


--
-- Name: ix_planungs_templates_benutzer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_planungs_templates_benutzer_id ON public.planungs_templates USING btree (benutzer_id);


--
-- Name: ix_planungs_templates_semester_typ; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_planungs_templates_semester_typ ON public.planungs_templates USING btree (semester_typ);


--
-- Name: ix_rolle_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_rolle_name ON public.rolle USING btree (name);


--
-- Name: ix_semester_auftrag_auftrag_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_semester_auftrag_auftrag_id ON public.semester_auftrag USING btree (auftrag_id);


--
-- Name: ix_semester_auftrag_dozent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_semester_auftrag_dozent ON public.semester_auftrag USING btree (dozent_id);


--
-- Name: ix_semester_auftrag_dozent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_semester_auftrag_dozent_id ON public.semester_auftrag USING btree (dozent_id);


--
-- Name: ix_semester_auftrag_semester; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_semester_auftrag_semester ON public.semester_auftrag USING btree (semester_id);


--
-- Name: ix_semester_auftrag_semester_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_semester_auftrag_semester_id ON public.semester_auftrag USING btree (semester_id);


--
-- Name: ix_semester_auftrag_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_semester_auftrag_status ON public.semester_auftrag USING btree (status);


--
-- Name: ix_semester_auftrag_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_semester_auftrag_unique ON public.semester_auftrag USING btree (semester_id, auftrag_id, dozent_id);


--
-- Name: ix_semester_ist_aktiv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_semester_ist_aktiv ON public.semester USING btree (ist_aktiv);


--
-- Name: ix_semester_ist_planungsphase; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_semester_ist_planungsphase ON public.semester USING btree (ist_planungsphase);


--
-- Name: ix_semester_kuerzel; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_semester_kuerzel ON public.semester USING btree (kuerzel);


--
-- Name: ix_semesterplanung_benutzer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_semesterplanung_benutzer_id ON public.semesterplanung USING btree (benutzer_id);


--
-- Name: ix_semesterplanung_benutzer_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_semesterplanung_benutzer_status ON public.semesterplanung USING btree (benutzer_id, status);


--
-- Name: ix_semesterplanung_planungsphase_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_semesterplanung_planungsphase_id ON public.semesterplanung USING btree (planungsphase_id);


--
-- Name: ix_semesterplanung_semester_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_semesterplanung_semester_id ON public.semesterplanung USING btree (semester_id);


--
-- Name: ix_semesterplanung_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_semesterplanung_status ON public.semesterplanung USING btree (status);


--
-- Name: ix_semesterplanung_status_semester; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_semesterplanung_status_semester ON public.semesterplanung USING btree (status, semester_id);


--
-- Name: ix_template_benutzer_aktiv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_template_benutzer_aktiv ON public.planungs_templates USING btree (benutzer_id, ist_aktiv);


--
-- Name: ix_template_modul_template; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_template_modul_template ON public.template_module USING btree (template_id);


--
-- Name: ix_template_module_modul_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_template_module_modul_id ON public.template_module USING btree (modul_id);


--
-- Name: ix_template_module_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_template_module_template_id ON public.template_module USING btree (template_id);


--
-- Name: ix_wunsch_freie_tage_semesterplanung_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_wunsch_freie_tage_semesterplanung_id ON public.wunsch_freie_tage USING btree (semesterplanung_id);


--
-- Name: archivierte_planungen archivierte_planungen_archiviert_von_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.archivierte_planungen
    ADD CONSTRAINT archivierte_planungen_archiviert_von_fkey FOREIGN KEY (archiviert_von) REFERENCES public.benutzer(id);


--
-- Name: archivierte_planungen archivierte_planungen_planungphase_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.archivierte_planungen
    ADD CONSTRAINT archivierte_planungen_planungphase_id_fkey FOREIGN KEY (planungphase_id) REFERENCES public.planungsphasen(id);


--
-- Name: archivierte_planungen archivierte_planungen_professor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.archivierte_planungen
    ADD CONSTRAINT archivierte_planungen_professor_id_fkey FOREIGN KEY (professor_id) REFERENCES public.benutzer(id);


--
-- Name: archivierte_planungen archivierte_planungen_semester_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.archivierte_planungen
    ADD CONSTRAINT archivierte_planungen_semester_id_fkey FOREIGN KEY (semester_id) REFERENCES public.semester(id);


--
-- Name: audit_log audit_log_benutzer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_benutzer_id_fkey FOREIGN KEY (benutzer_id) REFERENCES public.benutzer(id) ON DELETE SET NULL;


--
-- Name: benachrichtigung benachrichtigung_empfaenger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.benachrichtigung
    ADD CONSTRAINT benachrichtigung_empfaenger_id_fkey FOREIGN KEY (empfaenger_id) REFERENCES public.benutzer(id) ON DELETE CASCADE;


--
-- Name: benutzer benutzer_dozent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.benutzer
    ADD CONSTRAINT benutzer_dozent_id_fkey FOREIGN KEY (dozent_id) REFERENCES public.dozent(id) ON DELETE SET NULL;


--
-- Name: benutzer benutzer_rolle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.benutzer
    ADD CONSTRAINT benutzer_rolle_id_fkey FOREIGN KEY (rolle_id) REFERENCES public.rolle(id) ON DELETE RESTRICT;


--
-- Name: deputats_betreuung deputats_betreuung_deputatsabrechnung_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deputats_betreuung
    ADD CONSTRAINT deputats_betreuung_deputatsabrechnung_id_fkey FOREIGN KEY (deputatsabrechnung_id) REFERENCES public.deputatsabrechnung(id) ON DELETE CASCADE;


--
-- Name: deputats_einstellungen deputats_einstellungen_erstellt_von_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deputats_einstellungen
    ADD CONSTRAINT deputats_einstellungen_erstellt_von_fkey FOREIGN KEY (erstellt_von) REFERENCES public.benutzer(id) ON DELETE SET NULL;


--
-- Name: deputats_ermaessigung deputats_ermaessigung_deputatsabrechnung_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deputats_ermaessigung
    ADD CONSTRAINT deputats_ermaessigung_deputatsabrechnung_id_fkey FOREIGN KEY (deputatsabrechnung_id) REFERENCES public.deputatsabrechnung(id) ON DELETE CASCADE;


--
-- Name: deputats_ermaessigung deputats_ermaessigung_semester_auftrag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deputats_ermaessigung
    ADD CONSTRAINT deputats_ermaessigung_semester_auftrag_id_fkey FOREIGN KEY (semester_auftrag_id) REFERENCES public.semester_auftrag(id) ON DELETE SET NULL;


--
-- Name: deputats_lehrexport deputats_lehrexport_deputatsabrechnung_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deputats_lehrexport
    ADD CONSTRAINT deputats_lehrexport_deputatsabrechnung_id_fkey FOREIGN KEY (deputatsabrechnung_id) REFERENCES public.deputatsabrechnung(id) ON DELETE CASCADE;


--
-- Name: deputats_lehrtaetigkeit deputats_lehrtaetigkeit_deputatsabrechnung_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deputats_lehrtaetigkeit
    ADD CONSTRAINT deputats_lehrtaetigkeit_deputatsabrechnung_id_fkey FOREIGN KEY (deputatsabrechnung_id) REFERENCES public.deputatsabrechnung(id) ON DELETE CASCADE;


--
-- Name: deputats_lehrtaetigkeit deputats_lehrtaetigkeit_geplantes_modul_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deputats_lehrtaetigkeit
    ADD CONSTRAINT deputats_lehrtaetigkeit_geplantes_modul_id_fkey FOREIGN KEY (geplantes_modul_id) REFERENCES public.geplante_module(id) ON DELETE SET NULL;


--
-- Name: deputats_vertretung deputats_vertretung_deputatsabrechnung_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deputats_vertretung
    ADD CONSTRAINT deputats_vertretung_deputatsabrechnung_id_fkey FOREIGN KEY (deputatsabrechnung_id) REFERENCES public.deputatsabrechnung(id) ON DELETE CASCADE;


--
-- Name: deputatsabrechnung deputatsabrechnung_benutzer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deputatsabrechnung
    ADD CONSTRAINT deputatsabrechnung_benutzer_id_fkey FOREIGN KEY (benutzer_id) REFERENCES public.benutzer(id) ON DELETE CASCADE;


--
-- Name: deputatsabrechnung deputatsabrechnung_genehmigt_von_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deputatsabrechnung
    ADD CONSTRAINT deputatsabrechnung_genehmigt_von_fkey FOREIGN KEY (genehmigt_von) REFERENCES public.benutzer(id) ON DELETE SET NULL;


--
-- Name: deputatsabrechnung deputatsabrechnung_planungsphase_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deputatsabrechnung
    ADD CONSTRAINT deputatsabrechnung_planungsphase_id_fkey FOREIGN KEY (planungsphase_id) REFERENCES public.planungsphasen(id) ON DELETE CASCADE;


--
-- Name: geplante_module geplante_module_modul_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.geplante_module
    ADD CONSTRAINT geplante_module_modul_id_fkey FOREIGN KEY (modul_id) REFERENCES public.modul(id) ON DELETE CASCADE;


--
-- Name: geplante_module geplante_module_po_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.geplante_module
    ADD CONSTRAINT geplante_module_po_id_fkey FOREIGN KEY (po_id) REFERENCES public.pruefungsordnung(id) ON DELETE CASCADE;


--
-- Name: geplante_module geplante_module_semesterplanung_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.geplante_module
    ADD CONSTRAINT geplante_module_semesterplanung_id_fkey FOREIGN KEY (semesterplanung_id) REFERENCES public.semesterplanung(id) ON DELETE CASCADE;


--
-- Name: modul_abhÃ¤ngigkeit modul_abhÃ¤ngigkeit_modul_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."modul_abhÃ¤ngigkeit"
    ADD CONSTRAINT "modul_abhÃ¤ngigkeit_modul_id_fkey" FOREIGN KEY (modul_id) REFERENCES public.modul(id) ON DELETE CASCADE;


--
-- Name: modul_abhÃ¤ngigkeit modul_abhÃ¤ngigkeit_po_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."modul_abhÃ¤ngigkeit"
    ADD CONSTRAINT "modul_abhÃ¤ngigkeit_po_id_fkey" FOREIGN KEY (po_id) REFERENCES public.pruefungsordnung(id) ON DELETE CASCADE;


--
-- Name: modul_abhÃ¤ngigkeit modul_abhÃ¤ngigkeit_voraussetzung_modul_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."modul_abhÃ¤ngigkeit"
    ADD CONSTRAINT "modul_abhÃ¤ngigkeit_voraussetzung_modul_id_fkey" FOREIGN KEY (voraussetzung_modul_id) REFERENCES public.modul(id) ON DELETE CASCADE;


--
-- Name: modul_arbeitsaufwand modul_arbeitsaufwand_modul_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_arbeitsaufwand
    ADD CONSTRAINT modul_arbeitsaufwand_modul_id_fkey FOREIGN KEY (modul_id) REFERENCES public.modul(id) ON DELETE CASCADE;


--
-- Name: modul_arbeitsaufwand modul_arbeitsaufwand_po_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_arbeitsaufwand
    ADD CONSTRAINT modul_arbeitsaufwand_po_id_fkey FOREIGN KEY (po_id) REFERENCES public.pruefungsordnung(id) ON DELETE CASCADE;


--
-- Name: modul_audit_log modul_audit_log_alt_dozent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_audit_log
    ADD CONSTRAINT modul_audit_log_alt_dozent_id_fkey FOREIGN KEY (alt_dozent_id) REFERENCES public.dozent(id) ON DELETE SET NULL;


--
-- Name: modul_audit_log modul_audit_log_geaendert_von_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_audit_log
    ADD CONSTRAINT modul_audit_log_geaendert_von_fkey FOREIGN KEY (geaendert_von) REFERENCES public.benutzer(id) ON DELETE SET NULL;


--
-- Name: modul_audit_log modul_audit_log_modul_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_audit_log
    ADD CONSTRAINT modul_audit_log_modul_id_fkey FOREIGN KEY (modul_id) REFERENCES public.modul(id) ON DELETE CASCADE;


--
-- Name: modul_audit_log modul_audit_log_neu_dozent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_audit_log
    ADD CONSTRAINT modul_audit_log_neu_dozent_id_fkey FOREIGN KEY (neu_dozent_id) REFERENCES public.dozent(id) ON DELETE SET NULL;


--
-- Name: modul_audit_log modul_audit_log_po_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_audit_log
    ADD CONSTRAINT modul_audit_log_po_id_fkey FOREIGN KEY (po_id) REFERENCES public.pruefungsordnung(id) ON DELETE CASCADE;


--
-- Name: modul_dozent modul_dozent_dozent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_dozent
    ADD CONSTRAINT modul_dozent_dozent_id_fkey FOREIGN KEY (dozent_id) REFERENCES public.dozent(id) ON DELETE CASCADE;


--
-- Name: modul_dozent modul_dozent_modul_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_dozent
    ADD CONSTRAINT modul_dozent_modul_id_fkey FOREIGN KEY (modul_id) REFERENCES public.modul(id) ON DELETE CASCADE;


--
-- Name: modul_dozent modul_dozent_po_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_dozent
    ADD CONSTRAINT modul_dozent_po_id_fkey FOREIGN KEY (po_id) REFERENCES public.pruefungsordnung(id) ON DELETE CASCADE;


--
-- Name: modul_dozent modul_dozent_vertreter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_dozent
    ADD CONSTRAINT modul_dozent_vertreter_id_fkey FOREIGN KEY (vertreter_id) REFERENCES public.dozent(id) ON DELETE SET NULL;


--
-- Name: modul_dozent modul_dozent_zweitpruefer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_dozent
    ADD CONSTRAINT modul_dozent_zweitpruefer_id_fkey FOREIGN KEY (zweitpruefer_id) REFERENCES public.dozent(id) ON DELETE SET NULL;


--
-- Name: modul_lehrform modul_lehrform_lehrform_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_lehrform
    ADD CONSTRAINT modul_lehrform_lehrform_id_fkey FOREIGN KEY (lehrform_id) REFERENCES public.lehrform(id) ON DELETE CASCADE;


--
-- Name: modul_lehrform modul_lehrform_modul_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_lehrform
    ADD CONSTRAINT modul_lehrform_modul_id_fkey FOREIGN KEY (modul_id) REFERENCES public.modul(id) ON DELETE CASCADE;


--
-- Name: modul_lehrform modul_lehrform_po_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_lehrform
    ADD CONSTRAINT modul_lehrform_po_id_fkey FOREIGN KEY (po_id) REFERENCES public.pruefungsordnung(id) ON DELETE CASCADE;


--
-- Name: modul_lernergebnisse modul_lernergebnisse_modul_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_lernergebnisse
    ADD CONSTRAINT modul_lernergebnisse_modul_id_fkey FOREIGN KEY (modul_id) REFERENCES public.modul(id) ON DELETE CASCADE;


--
-- Name: modul_lernergebnisse modul_lernergebnisse_po_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_lernergebnisse
    ADD CONSTRAINT modul_lernergebnisse_po_id_fkey FOREIGN KEY (po_id) REFERENCES public.pruefungsordnung(id) ON DELETE CASCADE;


--
-- Name: modul_literatur modul_literatur_modul_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_literatur
    ADD CONSTRAINT modul_literatur_modul_id_fkey FOREIGN KEY (modul_id) REFERENCES public.modul(id) ON DELETE CASCADE;


--
-- Name: modul_literatur modul_literatur_po_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_literatur
    ADD CONSTRAINT modul_literatur_po_id_fkey FOREIGN KEY (po_id) REFERENCES public.pruefungsordnung(id) ON DELETE CASCADE;


--
-- Name: modul modul_po_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul
    ADD CONSTRAINT modul_po_id_fkey FOREIGN KEY (po_id) REFERENCES public.pruefungsordnung(id) ON DELETE CASCADE;


--
-- Name: modul_pruefung modul_pruefung_modul_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_pruefung
    ADD CONSTRAINT modul_pruefung_modul_id_fkey FOREIGN KEY (modul_id) REFERENCES public.modul(id) ON DELETE CASCADE;


--
-- Name: modul_pruefung modul_pruefung_po_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_pruefung
    ADD CONSTRAINT modul_pruefung_po_id_fkey FOREIGN KEY (po_id) REFERENCES public.pruefungsordnung(id) ON DELETE CASCADE;


--
-- Name: modul_seiten modul_seiten_modul_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_seiten
    ADD CONSTRAINT modul_seiten_modul_id_fkey FOREIGN KEY (modul_id) REFERENCES public.modul(id) ON DELETE CASCADE;


--
-- Name: modul_seiten modul_seiten_modulhandbuch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_seiten
    ADD CONSTRAINT modul_seiten_modulhandbuch_id_fkey FOREIGN KEY (modulhandbuch_id) REFERENCES public.modulhandbuch(id) ON DELETE CASCADE;


--
-- Name: modul_seiten modul_seiten_po_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_seiten
    ADD CONSTRAINT modul_seiten_po_id_fkey FOREIGN KEY (po_id) REFERENCES public.pruefungsordnung(id) ON DELETE CASCADE;


--
-- Name: modul_sprache modul_sprache_modul_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_sprache
    ADD CONSTRAINT modul_sprache_modul_id_fkey FOREIGN KEY (modul_id) REFERENCES public.modul(id) ON DELETE CASCADE;


--
-- Name: modul_sprache modul_sprache_po_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_sprache
    ADD CONSTRAINT modul_sprache_po_id_fkey FOREIGN KEY (po_id) REFERENCES public.pruefungsordnung(id) ON DELETE CASCADE;


--
-- Name: modul_sprache modul_sprache_sprache_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_sprache
    ADD CONSTRAINT modul_sprache_sprache_id_fkey FOREIGN KEY (sprache_id) REFERENCES public.sprache(id) ON DELETE CASCADE;


--
-- Name: modul_studiengang modul_studiengang_modul_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_studiengang
    ADD CONSTRAINT modul_studiengang_modul_id_fkey FOREIGN KEY (modul_id) REFERENCES public.modul(id) ON DELETE CASCADE;


--
-- Name: modul_studiengang modul_studiengang_po_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_studiengang
    ADD CONSTRAINT modul_studiengang_po_id_fkey FOREIGN KEY (po_id) REFERENCES public.pruefungsordnung(id) ON DELETE CASCADE;


--
-- Name: modul_studiengang modul_studiengang_studiengang_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_studiengang
    ADD CONSTRAINT modul_studiengang_studiengang_id_fkey FOREIGN KEY (studiengang_id) REFERENCES public.studiengang(id) ON DELETE CASCADE;


--
-- Name: modul_voraussetzungen modul_voraussetzungen_modul_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_voraussetzungen
    ADD CONSTRAINT modul_voraussetzungen_modul_id_fkey FOREIGN KEY (modul_id) REFERENCES public.modul(id) ON DELETE CASCADE;


--
-- Name: modul_voraussetzungen modul_voraussetzungen_po_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modul_voraussetzungen
    ADD CONSTRAINT modul_voraussetzungen_po_id_fkey FOREIGN KEY (po_id) REFERENCES public.pruefungsordnung(id) ON DELETE CASCADE;


--
-- Name: modulhandbuch modulhandbuch_po_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modulhandbuch
    ADD CONSTRAINT modulhandbuch_po_id_fkey FOREIGN KEY (po_id) REFERENCES public.pruefungsordnung(id) ON DELETE CASCADE;


--
-- Name: modulhandbuch modulhandbuch_studiengang_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modulhandbuch
    ADD CONSTRAINT modulhandbuch_studiengang_id_fkey FOREIGN KEY (studiengang_id) REFERENCES public.studiengang(id) ON DELETE SET NULL;


--
-- Name: phase_submissions phase_submissions_abgelehnt_von_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phase_submissions
    ADD CONSTRAINT phase_submissions_abgelehnt_von_fkey FOREIGN KEY (abgelehnt_von) REFERENCES public.benutzer(id);


--
-- Name: phase_submissions phase_submissions_freigegeben_von_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phase_submissions
    ADD CONSTRAINT phase_submissions_freigegeben_von_fkey FOREIGN KEY (freigegeben_von) REFERENCES public.benutzer(id);


--
-- Name: phase_submissions phase_submissions_planung_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phase_submissions
    ADD CONSTRAINT phase_submissions_planung_id_fkey FOREIGN KEY (planung_id) REFERENCES public.semesterplanung(id) ON DELETE CASCADE;


--
-- Name: phase_submissions phase_submissions_planungphase_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phase_submissions
    ADD CONSTRAINT phase_submissions_planungphase_id_fkey FOREIGN KEY (planungphase_id) REFERENCES public.planungsphasen(id) ON DELETE CASCADE;


--
-- Name: phase_submissions phase_submissions_professor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phase_submissions
    ADD CONSTRAINT phase_submissions_professor_id_fkey FOREIGN KEY (professor_id) REFERENCES public.benutzer(id);


--
-- Name: planungs_templates planungs_templates_benutzer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planungs_templates
    ADD CONSTRAINT planungs_templates_benutzer_id_fkey FOREIGN KEY (benutzer_id) REFERENCES public.benutzer(id) ON DELETE CASCADE;


--
-- Name: planungsphasen planungsphasen_geschlossen_von_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planungsphasen
    ADD CONSTRAINT planungsphasen_geschlossen_von_fkey FOREIGN KEY (geschlossen_von) REFERENCES public.benutzer(id);


--
-- Name: planungsphasen planungsphasen_semester_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planungsphasen
    ADD CONSTRAINT planungsphasen_semester_id_fkey FOREIGN KEY (semester_id) REFERENCES public.semester(id) ON DELETE CASCADE;


--
-- Name: semester_auftrag semester_auftrag_auftrag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.semester_auftrag
    ADD CONSTRAINT semester_auftrag_auftrag_id_fkey FOREIGN KEY (auftrag_id) REFERENCES public.auftrag(id) ON DELETE CASCADE;


--
-- Name: semester_auftrag semester_auftrag_beantragt_von_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.semester_auftrag
    ADD CONSTRAINT semester_auftrag_beantragt_von_fkey FOREIGN KEY (beantragt_von) REFERENCES public.benutzer(id) ON DELETE SET NULL;


--
-- Name: semester_auftrag semester_auftrag_dozent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.semester_auftrag
    ADD CONSTRAINT semester_auftrag_dozent_id_fkey FOREIGN KEY (dozent_id) REFERENCES public.dozent(id) ON DELETE CASCADE;


--
-- Name: semester_auftrag semester_auftrag_genehmigt_von_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.semester_auftrag
    ADD CONSTRAINT semester_auftrag_genehmigt_von_fkey FOREIGN KEY (genehmigt_von) REFERENCES public.benutzer(id) ON DELETE SET NULL;


--
-- Name: semester_auftrag semester_auftrag_semester_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.semester_auftrag
    ADD CONSTRAINT semester_auftrag_semester_id_fkey FOREIGN KEY (semester_id) REFERENCES public.semester(id) ON DELETE CASCADE;


--
-- Name: semesterplanung semesterplanung_benutzer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.semesterplanung
    ADD CONSTRAINT semesterplanung_benutzer_id_fkey FOREIGN KEY (benutzer_id) REFERENCES public.benutzer(id) ON DELETE CASCADE;


--
-- Name: semesterplanung semesterplanung_freigegeben_von_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.semesterplanung
    ADD CONSTRAINT semesterplanung_freigegeben_von_fkey FOREIGN KEY (freigegeben_von) REFERENCES public.benutzer(id) ON DELETE SET NULL;


--
-- Name: semesterplanung semesterplanung_planungsphase_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.semesterplanung
    ADD CONSTRAINT semesterplanung_planungsphase_id_fkey FOREIGN KEY (planungsphase_id) REFERENCES public.planungsphasen(id) ON DELETE SET NULL;


--
-- Name: semesterplanung semesterplanung_semester_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.semesterplanung
    ADD CONSTRAINT semesterplanung_semester_id_fkey FOREIGN KEY (semester_id) REFERENCES public.semester(id) ON DELETE CASCADE;


--
-- Name: template_module template_module_modul_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.template_module
    ADD CONSTRAINT template_module_modul_id_fkey FOREIGN KEY (modul_id) REFERENCES public.modul(id) ON DELETE CASCADE;


--
-- Name: template_module template_module_po_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.template_module
    ADD CONSTRAINT template_module_po_id_fkey FOREIGN KEY (po_id) REFERENCES public.pruefungsordnung(id) ON DELETE CASCADE;


--
-- Name: template_module template_module_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.template_module
    ADD CONSTRAINT template_module_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.planungs_templates(id) ON DELETE CASCADE;


--
-- Name: wunsch_freie_tage wunsch_freie_tage_semesterplanung_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wunsch_freie_tage
    ADD CONSTRAINT wunsch_freie_tage_semesterplanung_id_fkey FOREIGN KEY (semesterplanung_id) REFERENCES public.semesterplanung(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict I7WE8rmEdFCvcjdFnbeXCgUZQYRwsqngGoIouYKEGGkRvWH1QDEelp9TaNPilzH

